<h1> Ro-bros </h1>

<h3> copyright © 2024 Team RN18. All Rights Reserved. </h3>

<H3> SYSTEM DATA: “RO-BROS”… </H3>

Play as 'R' and 'N', discarded robots fighting to 
save humanity from the corrupt surveillance 
company WannaSmile.Co... 

In this co-op first person shooter you must 
rely on each other by fighting their way 
through hordes of enemy CCTB robots whilst 
recharging each others batteries and 
destroying generators.


DESCRIPTION IS PROPERTY OF WANNASMILE.co


Developers: RN18: LUDLOW, LUKE, NAKAJIMA, GINSEI, 
PATON-EADES, KUMO, POOLEY-GREY, BEN, SMITH, ELLIE, 
STANS-MINCHINGTON, BEN, WILLIAMSON-BATES, FINN 
