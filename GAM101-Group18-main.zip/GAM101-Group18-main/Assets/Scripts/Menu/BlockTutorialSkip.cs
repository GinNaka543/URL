using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockTutorialSkip : MonoBehaviour
{
    void Awake()
    {
        PauseMenu.instance.OnPause += SetVisibility;
    }

    void SetVisibility()
    {
        foreach (var player in PlayerManager.instance.players)
        {
            foreach(var partSlot in player.GetComponent<PlayerController>().partSlots)
            {
                if (partSlot.slotType == SlotTypes.Wind)
                    continue;

                if (partSlot.contents)
                {
                    gameObject.SetActive(false);
                    return;
                }
            }
        }

        gameObject.SetActive(true);
    }
}
