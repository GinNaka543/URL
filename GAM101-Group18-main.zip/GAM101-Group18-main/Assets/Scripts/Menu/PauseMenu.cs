using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PauseMenu : MonoBehaviour
{
    public static PauseMenu instance;
    public bool paused = false;

    public delegate void PauseVoid();
    public event PauseVoid OnPause;
    public event PauseVoid OnResume;

    private void Awake()
    {
        instance = this;
        gameObject.SetActive(false);
    }

    public void TogglePause()
    {
        paused = !paused;

        gameObject.SetActive(paused);

        Time.timeScale = paused ? 0f : 1f;
        //locks cursor for player and allows it to be moved for user in pause menu
        Cursor.lockState = (paused) ? CursorLockMode.None : CursorLockMode.Confined;
        Cursor.visible = paused;

        if (paused)
        {
            CursorManager.CreateCursorManager();
            OnPause?.Invoke();
        }
        else
        {
            Destroy(CursorManager.instance.gameObject);
            OnResume?.Invoke();
        }
    }
}
