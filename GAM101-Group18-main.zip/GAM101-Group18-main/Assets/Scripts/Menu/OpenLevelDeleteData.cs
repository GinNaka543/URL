using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class OpenLevelDeleteData : MonoBehaviour
{
    [SerializeField] int levelIndex;

    public void OpenLevel()
    {
        PlayerPrefs.DeleteKey("Player0");
        PlayerPrefs.DeleteKey("Player1");
        PlayerPrefs.Save();

        SceneManager.LoadScene(levelIndex);
    }
}
