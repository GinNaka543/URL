using System.Collections;
using System.Collections.Generic;
using System.Threading;
using UnityEngine;
using UnityEngine.InputSystem.XR.Haptics;
using UnityEngine.SceneManagement;
using UnityEngine.TextCore.Text;

public class Menu : MonoBehaviour
{
    //Lets the user go to the information scene
    public void OnInfoButton()
    {
        Instantiate(Resources.Load("UI/Info"));
    }
    //allows the user to return to the main menu from the info scene
    public void OnReturnButton()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene(0);
    }
    //Called when we click the "Quit" button.
    //Quits the build
    //Does not work in unity game scene, only in the unity build
    public void OnQuitButton()
    {
        Application.Quit();
    }
    //Called when the user presses escape in the game
    //Quits to the main menu/Loads the main menu scene
    //timescale to reset the movement after going back to the main menu
    public void OnPauseButton()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene(0);
    }
    //Allows the player to replay the level from the beginning
    //resets everything weapons, enemies and character positions
    public void OnRetryLevelButton()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    /*When the continue button is pressed the time would treturn to
    normal and the Toggle pause instance will be turned to false,
    removing the pause screen and allowing the players to carry on
    with the game without starting over*/
    public void OnContinueButton()
    {
        Time.timeScale = 1.0f;
        PauseMenu.instance.TogglePause();
        gameObject.SetActive(false);
    }

    public void NextLevel()
    {
        Time.timeScale = 1.0f;
        SaveManager.instance.Save();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
