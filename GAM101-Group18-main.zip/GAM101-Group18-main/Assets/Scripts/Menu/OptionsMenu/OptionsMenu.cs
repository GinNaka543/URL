using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OptionsMenu : MonoBehaviour
{
    PauseMenu menu;

    public void CloseMenu()
    {
        PlayerPrefs.Save();

        if(menu)
            menu.OnResume -= CloseMenu;

        Destroy(gameObject);
    }

    private void Start()
    {
        menu = GetComponentInParent<PauseMenu>();

        if(menu)
            menu.OnResume += CloseMenu;
    }
}
