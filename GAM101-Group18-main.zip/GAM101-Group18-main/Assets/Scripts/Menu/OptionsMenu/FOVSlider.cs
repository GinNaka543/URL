using UnityEngine.UI;
using UnityEngine;
using System.Linq;

public class FOVSlider : MonoBehaviour
{
    string prefKey;

    private void Awake()
    {
        // is p0Xsens or //p0Ysens for the x and y sens of player 1
        prefKey = "p" + GetComponentInParent<PlayerSettings>().PlayerID + "FOV";
        GetComponent<Slider>().value = PlayerPrefs.GetFloat(prefKey, 0.5f);
    }

    public void OnSliderChanged()
    {
        float value = GetComponent<Slider>().value;
        PlayerPrefs.SetFloat(prefKey, value);

        if (PlayerManager.instance)
        {
            PlayerManager.instance.players.Where
                (x => x.GetComponent<PlayerController>().PlayerID == GetComponentInParent<PlayerSettings>().PlayerID)
                .First().GetComponent<PlayerController>().UpdateFOV();
        }
    }
}
