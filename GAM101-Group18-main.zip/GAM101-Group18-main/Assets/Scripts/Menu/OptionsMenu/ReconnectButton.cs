using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReconnectButton : MonoBehaviour
{
    public void Reconnect()
    {
        InputManager.instance.ResetDevices();
    }
}
