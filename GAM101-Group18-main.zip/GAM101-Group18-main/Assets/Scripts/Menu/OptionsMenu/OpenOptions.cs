using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenOptions : MonoBehaviour
{
    public void OpenOptionsMenu()
    {
        GameObject settings = Instantiate(Resources.Load<GameObject>("UI/SettingsMenu"));
        var pause = GetComponentInParent<PauseMenu>();

        if (pause)
        {
            settings.transform.SetParent(pause.transform);
        }
    }
}
