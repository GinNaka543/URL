using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class TogglePreference : MonoBehaviour
{
    [SerializeField] string preferenceName;

    [SerializeField] bool defaultValue;
    [SerializeField] bool playerDependant;

    private void Awake()
    {
        preferenceName += playerDependant ? GetComponentInParent<PlayerSettings>().PlayerID : "";
        UpdateButton(PlayerPrefs.GetInt(preferenceName, defaultValue ? 1 : 0) == 1);
    }

    public void ToggleState()
    {
        bool newState = !(PlayerPrefs.GetInt(preferenceName, defaultValue ? 1 : 0) == 1);
        PlayerPrefs.SetInt(preferenceName, newState ? 1 : 0);

        UpdateButton(newState);
    }

    private void UpdateButton(bool preferenceState)
    {
        GetComponent<Image>().color = preferenceState ? new Color(0.35f, 1, 0.35f) : new Color(1, 0.35f, 0.35f);
        GetComponentInChildren<TextMeshProUGUI>().text = preferenceState ? "ON" : "OFF";
    }
}
