using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SensitivitySlider : MonoBehaviour
{
    [SerializeField] bool isY;
    string prefKey;

    private void Awake()
    {
        // is p0Xsens or //p0Ysens for the x and y sens of player 1
        prefKey = "p" + GetComponentInParent<PlayerSettings>().PlayerID +
            (isY ? "Y" : "X") + "sens";
        GetComponent<Slider>().value = PlayerPrefs.GetFloat(prefKey, 1f);
    }

    public void OnSliderChanged()
    {
        PlayerPrefs.SetFloat(prefKey, GetComponent<Slider>().value);
    }
}
