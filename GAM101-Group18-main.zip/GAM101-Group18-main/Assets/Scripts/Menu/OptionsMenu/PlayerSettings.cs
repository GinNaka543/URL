using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSettings : MonoBehaviour
{
    public int PlayerID => playerID;
    [SerializeField] int playerID = 0;
}
