using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class TutorialOnly : MonoBehaviour
{
    private void Awake()
    {
        if(SceneManager.GetActiveScene().buildIndex != 2)
        {
            gameObject.SetActive(false);
        }
    }
}
