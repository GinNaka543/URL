using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public abstract class DifficultyButton : MonoBehaviour
{
    public void SetMode()
    {
        Difficulty difficulty = new Difficulty();

        ApplyDifficulty(difficulty);

        DifficultyManager.Difficulty = difficulty;
        OnPlayButton();
    }

    public abstract void ApplyDifficulty(Difficulty difficulty);

    //Called when we click the "Play" button.
    //Takes the player to the first level
    public void OnPlayButton()
    {
        Instantiate(Resources.Load<GameObject>("UI/MainMenu/Gamemodes"));
    }
}
