public class HardButton : DifficultyButton
{
    public override void ApplyDifficulty(Difficulty difficulty) { }
}
