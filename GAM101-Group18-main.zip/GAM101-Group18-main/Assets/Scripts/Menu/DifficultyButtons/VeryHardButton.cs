public class VeryHardButton : DifficultyButton
{
    public override void ApplyDifficulty(Difficulty difficulty)
    {
        difficulty.SetKey(DifParam.maxEnemySpawn, 5);
        difficulty.SetKey(DifParam.enemyLimit, 25);

        difficulty.SetKey(DifParam.graceTime, 15);
        difficulty.SetKey(DifParam.waveTime, 25);
    }
}
