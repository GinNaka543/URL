using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DifficultyParamText : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<CustomDifficultyValue>().DifficultyValueChange = UpdateText;
    }

    void UpdateText(float amount)
    {
        GetComponent<TextMeshProUGUI>().text = (Mathf.Round(amount * 10) * 0.1f).ToString();
    }
}
