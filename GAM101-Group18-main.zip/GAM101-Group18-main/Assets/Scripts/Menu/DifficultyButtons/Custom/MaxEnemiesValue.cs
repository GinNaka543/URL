using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MaxEnemiesValue : CustomDifficultyValue
{
    protected override void ChangeValueByIncrement(float increment)
    {
        if(CustomDifficultyManager.Instance.customDifficulty.difficultyValues.GetValueOrDefault(valueType) + increment
            < CustomDifficultyManager.Instance.customDifficulty.difficultyValues.GetValueOrDefault(DifParam.minEnemySpawn))
        {
            return;
        }

        base.ChangeValueByIncrement(increment);
    }
}
