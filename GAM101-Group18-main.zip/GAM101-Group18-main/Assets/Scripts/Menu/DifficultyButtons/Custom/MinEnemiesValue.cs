using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinEnemiesValue : CustomDifficultyValue
{
    protected override void ChangeValueByIncrement(float increment)
    {
        if(CustomDifficultyManager.Instance.customDifficulty.difficultyValues.GetValueOrDefault(valueType) + increment
            > CustomDifficultyManager.Instance.customDifficulty.difficultyValues.GetValueOrDefault(DifParam.maxEnemySpawn))
        {
            return;
        }

        base.ChangeValueByIncrement(increment);
    }
}
