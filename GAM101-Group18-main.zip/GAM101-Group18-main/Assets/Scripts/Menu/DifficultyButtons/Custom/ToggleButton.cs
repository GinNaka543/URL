using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class ToggleButton : MonoBehaviour
{
    [SerializeField] DifParam valueType;

    public void OnPress()
    {
        CustomDifficultyManager.Instance.customDifficulty.SetKey(valueType, CustomDifficultyManager.Instance.customDifficulty.difficultyValues[valueType] == 1 ? 0 : 1);

        bool isOn = CustomDifficultyManager.Instance.customDifficulty.difficultyValues[valueType] == 1;

        GetComponent<Button>().image.color = isOn ? new Color(0.47f,1,0.47f) : new Color(1,0.29f,0.29f);
        GetComponentInChildren<TextMeshProUGUI>().text = isOn ? "On" : "Off";

    }
}
