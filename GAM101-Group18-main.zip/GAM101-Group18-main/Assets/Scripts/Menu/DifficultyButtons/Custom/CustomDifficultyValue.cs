using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomDifficultyValue : MonoBehaviour
{
    [SerializeField]
    public DifParam valueType;

    [SerializeField]
    float incrementAmount = 1;

    [SerializeField]
    float minimumValue = 1;

    [SerializeField]
    float maximumValue = 999;

    public delegate void ValueChange(float newAmount);
    public ValueChange DifficultyValueChange;

    private void Start()
    {
        ChangeValueByIncrement(0);
    }

    public void IncrementValue()
    {
        ChangeValueByIncrement(incrementAmount);
    }

    public void DecrementValue()
    {
        ChangeValueByIncrement(-incrementAmount);
    }

    protected virtual void ChangeValueByIncrement(float increment)
    {
        float newValue = Mathf.Clamp(CustomDifficultyManager.Instance.customDifficulty.difficultyValues.GetValueOrDefault(valueType) + increment, minimumValue, maximumValue);
        CustomDifficultyManager.Instance.customDifficulty.SetKey(valueType, newValue);
        DifficultyValueChange(newValue);
    }
}
