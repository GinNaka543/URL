using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class DifficultyParamTitle : MonoBehaviour
{
    private void Awake()
    {
        GetComponent<TextMeshProUGUI>().text =
            GetComponentInParent<CustomDifficultyValue>().valueType.ToString();
    }
}
