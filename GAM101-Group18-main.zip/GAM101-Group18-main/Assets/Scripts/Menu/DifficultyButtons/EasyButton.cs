public class EasyButton : DifficultyButton
{
    public override void ApplyDifficulty(Difficulty difficulty)
    {
        difficulty.SetKey(DifParam.maxEnemySpawn, 3);
        difficulty.SetKey(DifParam.enemyLimit, 9);

        difficulty.SetKey(DifParam.graceTime, 30);

        difficulty.SetKey(DifParam.generatorHealthMult, 0.6f);
        difficulty.SetKey(DifParam.playerHealthMult, 2.0f);
        difficulty.SetKey(DifParam.enemyHealthMult, 0.4f);
    }
}
