using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenCustomMenu : MonoBehaviour
{
    public void CreateCustomDifficultyMenu()
    {
        Instantiate(Resources.Load("UI/MainMenu/CustomDifficulty"));
    }
}
