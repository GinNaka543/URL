using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomButton : DifficultyButton
{
    public override void ApplyDifficulty(Difficulty difficulty)
    {
        difficulty.difficultyValues = CustomDifficultyManager.Instance.customDifficulty.difficultyValues;
    }
}
