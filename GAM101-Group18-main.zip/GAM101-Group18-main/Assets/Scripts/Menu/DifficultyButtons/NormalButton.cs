public class NormalButton : DifficultyButton
{
    public override void ApplyDifficulty(Difficulty difficulty)
    {
        difficulty.SetKey(DifParam.maxEnemySpawn, 3);
        difficulty.SetKey(DifParam.enemyLimit, 10);

        difficulty.SetKey(DifParam.graceTime, 25);

        difficulty.SetKey(DifParam.generatorHealthMult, 0.8f);
        difficulty.SetKey(DifParam.playerHealthMult, 1.5f);
        difficulty.SetKey(DifParam.enemyHealthMult, 0.7f);

        difficulty.ranked = true;
    }
}
