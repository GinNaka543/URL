using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenDifficultyMenu : MonoBehaviour
{
    public void CreateDifficultyMenu()
    {
        Instantiate(Resources.Load("UI/MainMenu/Difficulties"));
    }
}
