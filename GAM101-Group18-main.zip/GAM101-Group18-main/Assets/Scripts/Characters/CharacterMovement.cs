using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterMovement : MonoBehaviour
{
    [SerializeField] protected float baseMovementSpeed = 12.0f;
    protected float movementSpeed;
    private const float forceStrength = 35f;

    public bool MovementDisabled { get { return movementDisabled; } set { movementDisabled = value; } }
    private bool movementDisabled;

    protected Rigidbody rb;

    public static int CheckMask { get { return ~(1 << LayerMask.NameToLayer("IgnoreMovement") | 1 << LayerMask.NameToLayer("EquipSlot") | 1 << LayerMask.NameToLayer("Bullet") | 1 << LayerMask.NameToLayer("GrabHitbox") | 1 << LayerMask.NameToLayer("Ignore Raycast")); } }

    protected virtual void Awake()
    {
        movementSpeed = baseMovementSpeed;
        rb = GetComponent<Rigidbody>();
    }

    protected void Movement(Vector3 direction)
    {
        Vector3 MovementForce = VectorFuncs.RemoveY((movementSpeed * direction) - rb.velocity * direction.magnitude);
        rb.AddForce(MovementForce * forceStrength);
    }

    protected void LookY(float amount)
    {
        rb.MoveRotation(Quaternion.Euler(0, amount + transform.eulerAngles.y, 0));
    }

    const float feetSize = 0.48f;

    protected bool IsOnGround()
    {
        if (Physics.SphereCast(transform.position + Vector3.up * (feetSize - 0.04f), feetSize, Vector3.down, out _, 1, CheckMask))
        {
            return true;
        }
        return false;
    }
}
