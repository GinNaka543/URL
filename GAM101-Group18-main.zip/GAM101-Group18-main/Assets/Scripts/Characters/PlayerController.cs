using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Controls;


public delegate void OnUse(bool isDown);
public class PlayerController : CharacterMovement
{
    [SerializeField] private int playerID = 0;

    public int PlayerID { get { return playerID; } }

    private Camera playerCamera;
    public Camera PlayerCamera { get { return playerCamera; } private set { playerCamera = value;  } }

    public ObjectHealth health;
    private Animator animator;

    private Gamepad Gamepad {
        get {
            if (InputManager.instance.usedGamepads[playerID] != null)
            {
                return InputManager.instance.usedGamepads[playerID];
            }
            else
            {
                return new Gamepad();
            }
        }
    }

    public List<PartSlot> partSlots = new();

    bool currentlyInAir;

    Vector3 startingPosition;

    protected override void Awake()
    {
        base.Awake();

        animator = GetComponentInChildren<Animator>();
        PlayerCamera = GetComponentInChildren<Camera>();
        health = GetComponent<ObjectHealth>();

        startingPosition = transform.position;

        UpdateFOV();

        health.OnDeath += OnDeath;
        health.OnRevive += OnRevive;
    }

    private void Start()
    {
        PlayerManager.instance.AddPlayer(gameObject);
        SaveManager.instance.Load(this);
    }

    void FixedUpdate()
    {
        Movement();

        bool InAir = !IsOnGround();
        bool onGroundChanged = InAir != currentlyInAir;
        currentlyInAir = InAir;

        //BEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEENNNNN CREATE THE VARIABLEEEEEEEEEEEEEEEEEEEEES!!!!!!!!
        animator.SetBool("Landing", onGroundChanged);
        animator.SetBool("Floating", InAir);

        Jump();

        if(transform.position.y < startingPosition.y - 150)
        {
            rb.velocity = Vector3.zero;
            rb.MovePosition(startingPosition);
        }
    }

    public delegate void PlayerVoid();
    public event PlayerVoid Moving;

    void Movement()
    {
        Vector3 dir = new Vector3(GetAxisButton(Gamepad.leftStick, "Horizontal").x, 0, GetAxisButton(Gamepad.leftStick, "Vertical").y);
        Movement(transform.rotation * dir);

        if (dir.magnitude > 0)
            Moving?.Invoke();

        animator.SetBool("IsMoving", dir.magnitude > 0);

        //print(dir.x + " / " + dir.z);

        animator.SetBool("IsForwardOrBack", dir.z != 0);
        animator.SetBool("IsLeftOrRight", dir.x != 0);

        animator.SetBool("IsLeft", dir.x <= 0);
    }

    void Update()
    {
        CameraMovement();

        UseObject();

        UseArms();

        Pause();
    }

    Coroutine jumping;

    public event PlayerVoid Jumped;
    void Jump()
    {
        if (GetButton(Gamepad.buttonSouth, "Jump") > 0)
        {
            if (IsOnGround())
            {
                rb.AddForce(0, 200, 0);
                Jumped?.Invoke();
                //Jumps here

                if(jumping != null)
                    StopCoroutine(jumping);

                //about to jump
                animator.SetBool("JumpStart", true);
                jumping = StartCoroutine(StopJump());
                return;
            }
        }

        //animator.SetBool("JumpStart", false);
    }

    IEnumerator StopJump()
    {
        yield return new WaitForSeconds(0.05f);
        animator.SetBool("JumpStart", false);
    }

    float rotX = 0;

    const float controllerSensY = 5;
    const float controllerSensX = 10;

    public event PlayerVoid Rotating;

    void CameraMovement()
    {
        float x = GetAxisButton(Gamepad.rightStick, "LookX", controllerSensX).x;
        float y = GetAxisButton(Gamepad.rightStick, "LookY", controllerSensY).y;

        if (Mathf.Abs(x) + Mathf.Abs(y) >= 0.2f)
            Rotating?.Invoke();

        LookY(x * PlayerPrefs.GetFloat("p" + playerID + "Xsens",1));
        rotX = Mathf.Clamp(y * PlayerPrefs.GetFloat("p" + playerID + "Ysens",1) + rotX, -80, 80);
        PlayerCamera.transform.localEulerAngles = new Vector3(-rotX, 0);
    }

    Interactable interacting;
    bool buttonDown;

    public event PlayerVoid OnInteract;
    public event PlayerVoid OnItemEquipped;

    public void ItemEquipped()
    {
        OnItemEquipped?.Invoke();
    }

    void UseObject()
    {
        if(GetButton(Gamepad.buttonWest, "Interact") > 0)
        {
            if (buttonDown)
            {
                return;

            }

            buttonDown = true;
            if (HeldObject)
            {
                HeldObject = null;
                return;
            }

            var hits = Physics.RaycastAll(PlayerCamera.transform.position, PlayerCamera.transform.forward, 3f, 
                ~(1 << LayerMask.NameToLayer("EquipSlot") | (1 << LayerMask.NameToLayer("Ignore Raycast"))))
                .OrderBy(x => Vector3.Distance(x.point, transform.position));

            foreach (var hit in hits)
            {
                Interactable interactable = hit.transform.GetComponentInParent<Interactable>();
                if (interactable)
                {
                    if (interactable as Part)
                    {
                        var part = interactable as Part;

                        if (part.Slot && part.Slot.Owner == this)
                            continue;
                    }

                    interactable.Interact(this);
                    interacting = interactable;
                    StartCoroutine(StillInteracting());
                    OnInteract?.Invoke();
                    break;
                }
                else
                    break;
            }
        }
        else if (buttonDown)
        {
            buttonDown = false;
            if (interacting)
            {
                interacting.EndInteract(this);
                interacting = null;
            }
            return;
        }
    }

    IEnumerator StillInteracting()
    {
        while (interacting)
        {
            var hits = Physics.RaycastAll(PlayerCamera.transform.position, PlayerCamera.transform.forward, 3f,
                ~(1 << LayerMask.NameToLayer("EquipSlot") | (1 << LayerMask.NameToLayer("Ignore Raycast"))))
                .OrderBy(x => Vector3.Distance(x.point, transform.position));

            bool wasHit = false;

            foreach (var hit in hits)
            {
                if (hit.transform.gameObject != interacting.gameObject)
                {
                    if (hit.transform)
                        if (hit.transform.GetComponent<ArmPart>())
                            continue;
                    break;
                }
                else
                    wasHit = true;
            }

            if (!wasHit)
            {
                interacting.EndInteract(this);
                interacting = null;
                yield break;
            }

            yield return new WaitForSeconds(0.1f);
        }
    }

    private GameObject heldObject;
    private Dictionary<MeshRenderer, Material> oldMats = new();

    public GameObject HeldObject 
    {
        get { return heldObject; }
        set
        {
            if (value)
            {

                foreach(MeshRenderer renderer in value.GetComponentsInChildren<MeshRenderer>())
                {
                    oldMats.Add(renderer, renderer.material);
                    renderer.material = Resources.Load("Materials/Held") as Material;
                }

                heldObject = value;
            }
            else
            {
                foreach (KeyValuePair<MeshRenderer, Material> model in oldMats)
                {
                    model.Key.material = model.Value;
                }
                oldMats.Clear();

                heldObject.GetComponent<Pickup>().Drop();
                heldObject = value;
            }
        }
    }

    

    public OnUse leftArm;
    public OnUse rightArm;

    private void UseArms()
    {
        float leftArmControls = GetButton(Gamepad.leftTrigger, "LeftArm");
        float rightArmControls = GetButton(Gamepad.rightTrigger, "RightArm");

        bool inverted = PlayerPrefs.GetInt("InvertArms" + playerID, 0) == 1;

        leftArm?.Invoke((inverted ? rightArmControls : leftArmControls) > 0.9);
        rightArm?.Invoke((inverted ? leftArmControls : rightArmControls) > 0.9);
    }


    bool pressed;

    //HERE!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    private void Pause()
    {
        if (GetButton(Gamepad.startButton, "Cancel") > 0.9)
        {
            if (!pressed)
            {
                pressed = true;
                PauseMenu.instance.TogglePause();
            }
        }
        else
        {
            pressed = false;
        }
    }


    float GetButton(InputControl button, string alt)
    {
        if(health.IsDead || PauseMenu.instance.paused && alt != "Cancel" || InputManager.instance.isPaused)
        {
            return 0.0f;
        }

        if(InputManager.instance.usedGamepads[playerID] == null)
        {
            return Input.GetAxis(alt);
        }
        else if (button != null)
        {
            return button.magnitude;
        }

        return 0.0f;
    }

    const float controllerSensitivityBonus = 35f;

    Vector2 GetAxisButton(StickControl button, string alt, float controllerMultiplier = 1.0f)
    {
        if (health.IsDead || PauseMenu.instance.paused || InputManager.instance.isPaused)
        {
            return Vector2.zero;
        }

        if (InputManager.instance.usedGamepads[playerID] == null)
        {
            return new Vector2(Input.GetAxis(alt), Input.GetAxis(alt));
        }
        else if (button != null)
        {
            return controllerMultiplier * controllerSensitivityBonus * Time.deltaTime * button.value;
        }
        return Vector2.zero;
    }

    //Old function for inputs
    [System.Obsolete("If you use this you are very cringe.")]
    float GetIDAxis(string axis)
    {
        if ((health.IsDead || PauseMenu.instance.paused) && axis != "Cancel")
        {
            return 0;
        }

        if (PlayerID <= 0)
        {
            return Input.GetAxis(axis);
        }
        else
        {
            return Input.GetAxis(axis + PlayerID.ToString());
        }
    }

    private void OnDestroy()
    {
        PlayerManager.instance.players.Remove(gameObject);
    }

    public void UpdateFOV()
    {
        float fov = PlayerPrefs.GetFloat("p" + playerID + "FOV", 0.5f);

        foreach (var camera in GetComponentsInChildren<Camera>())
        {
            camera.fieldOfView = 40 + fov * 90; 
        }
    }

    void OnDeath()
    {
        animator.SetBool("isDead", true);
        animator.SetTrigger("justDied");
    }

    void OnRevive()
    {
        animator.SetBool("isDead", false);
    }
}
