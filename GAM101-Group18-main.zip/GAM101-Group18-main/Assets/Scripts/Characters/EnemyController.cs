using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyController : CharacterMovement
{
    protected NavMeshPath path;
    protected GameObject target;

    protected NavMeshObstacle obstacle;

    protected bool updatePathByManager = true;
    public bool UpdatePathByManager { get {  return updatePathByManager; } }

    public GameObject Target
    {
        get
        { 
            if(target == null)
            {
                return gameObject;
            }
            return target;
        }
        protected set { target = value; }
    }

    bool isPanicking;
    bool IsPanicking 
    { 
        get 
        {
            if (GetComponent<ObjectHealth>().Health >= GetComponent<ObjectHealth>().MaxHealth)
            {
                isPanicking = false;
            }
            return isPanicking; 
        }
        set
        {            
            isPanicking = value;
            isPacifist = isPanicking;
        }
    }
    protected bool isPacifist;

    protected override void Awake()
    {
        base.Awake();
        path = new NavMeshPath();

        obstacle = GetComponent<NavMeshObstacle>();
        GetComponent<ObjectHealth>().OnDeath += Death;
        GetComponent<ObjectHealth>().OnDamaged += OnDamaged;
    }

    private void Start()
    {
        AIManager.instance.enemies.Add(this);
    }

    void FixedUpdate()
    {
        MoveToTarget();
    }

    protected int targettedPoint;

    public delegate void onPathUpdate();
    public event onPathUpdate OnPathUpdate;

    virtual public IEnumerator UpdatePath()
    {
        OnPathUpdate?.Invoke();

        obstacle.enabled = false;
        yield return null;
        if (this)
        {
            path = PlayerManager.instance.ClosestObject(transform.position, (IsPanicking ? AIManager.instance.generators : PlayerManager.instance.players).ToArray(), out target);
            //!!!!!!!!!!!!!!!!! SCP CODE !!!!!!!!!!!!!!!!!!!!!!!

            //ITEM #: SCP-52
            //OBJECT CLASS: KETER

            //Special Containment Procedures: Just don't delete this line of code

            /* -> */ for (int i = 0; i < path.corners.Length - 1; i++); /* <- */
            
            //This line of code is like the TF2 coconut.jpg dont delete it or else...

            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            
            targettedPoint = 0;
            obstacle.enabled = true;
        }
    }

    const float rotSpeed = 5;

    protected Vector3 PointDir()
    {
        if (path == null)
            return Vector3.zero;

        if (path.corners.Length <= 0)
        {
            return Vector3.zero;
        }

        if (Vector3.Distance(path.corners[targettedPoint], transform.position) < 1f)
        {
            if (targettedPoint + 1 < path.corners.Length)
            {
                targettedPoint++;
            }
        }

        return Vector3.Normalize(VectorFuncs.RemoveY(path.corners[targettedPoint] - transform.position));
    }

    protected virtual void MoveToTarget()
    {
        Vector3 dir = PointDir();
        FaceTarget(dir);
        Movement(dir);
    }

    protected void FaceTarget(Vector3 dir)
    {
        LookY(((Quaternion.FromToRotation(transform.forward, dir).eulerAngles.y + 180) % 360 - 180) * Time.deltaTime * rotSpeed);
    }

    protected void Death()
    {
        AIManager.instance.enemies.Remove(this);
        Destroy(gameObject);
    }

    private void OnDamaged()
    {
        float healthPercentage = 1-((float)GetComponent<ObjectHealth>().Health / GetComponent<ObjectHealth>().MaxHealth);
        if (healthPercentage > 0.4 && healthPercentage*0.2 > UnityEngine.Random.value)
        {
            IsPanicking = true;
        }
    }
}
