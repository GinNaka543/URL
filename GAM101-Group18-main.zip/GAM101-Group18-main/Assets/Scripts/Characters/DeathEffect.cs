using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathEffect : MonoBehaviour
{
    [SerializeField] GameObject effect;
    [SerializeField] AudioClip sound;
    [SerializeField] GameObject lights;

    void Start()
    {
        GetComponent<ObjectHealth>().OnDeath += delegate
        {
            if(effect)
                Instantiate(effect).transform.position = transform.position;
            if(sound)
                AudioSource.PlayClipAtPoint(sound, transform.position, 1);
            if(lights)
                lights.SetActive(false);
        };
    }
}
