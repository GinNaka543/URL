using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class ObjectHealth : MonoBehaviour
{
    bool isDead;
    public bool IsDead {  get { return isDead; } }

    int health;
    public int Health
    {
        get { return health; }
        private set
        {
            health = value;
            OnHealthChanged?.Invoke(this);

            if (health <= 0)
            {
                if (!isDead)
                {
                    isDead = true;
                    OnDeath?.Invoke();
                }
            }
            else if (health > 0 && isDead)
            {
                isDead = false;
                OnRevive?.Invoke();
            }
        }
    }
    [SerializeField] int maxHealth = 100;
    public int MaxHealth { get { return maxHealth; } private set { maxHealth = value; } }

    int degradation;

    const int degradationCounterStart = 5;

    public int Degradation 
    { 
        get{ return degradation; }
        private set 
        { 
            degradation = value;
            Health = Mathf.Min(Health, maxHealth - Degradation);
            OnDegradationChanged?.Invoke(this);
        } 
    }

    int degradationCounter = degradationCounterStart;

    public int DegredationCounter
    { 
        get { return degradationCounter; }
        set
        {
            if (degradationCounter <= 0)
            {
                Degradation+=5;
                degradationCounter = degradationCounterStart;
                return;
            }
            degradationCounter = value;
        } 
    }

    public delegate void onDeath();
    public event onDeath OnDeath;

    public delegate void onRevive();
    public event onRevive OnRevive;

    public delegate void onDamaged();
    public event onDamaged OnDamaged;

    public delegate void onDamagedAmount(int amount);
    public event onDamagedAmount OnDamagedAmount;

    public delegate void onHealthChanged(ObjectHealth health);
    public event onHealthChanged OnHealthChanged;

    public delegate void onDegradationChanged(ObjectHealth health);
    public event onDegradationChanged OnDegradationChanged;

    private void Awake()
    {
        if (GetComponent<PlayerController>())
            maxHealth = (int)(maxHealth * DifficultyManager.GetValue(DifParam.playerHealthMult));

        if (GetComponent<EnemyController>())
            maxHealth = (int)(maxHealth * DifficultyManager.GetValue(DifParam.enemyHealthMult));

        if (GetComponent<Generator>())
            maxHealth = (int)(maxHealth * DifficultyManager.GetValue(DifParam.generatorHealthMult));

        Health = MaxHealth;
    }

    public void Damage(int amount)
    {
        OnDamaged?.Invoke();
        OnDamagedAmount?.Invoke(amount);

        AudioSource.PlayClipAtPoint(Resources.Load<AudioClip>("Sounds/Damage_sound"), transform.position);

        Health = Mathf.Max(Health - amount, 0);
    }

    public bool Heal(int amount)
    {
        if(Health < maxHealth - Degradation)
        {
            Health = Mathf.Min(Health + amount, maxHealth - Degradation);
            return true;
        }
        return false;
    }
}
