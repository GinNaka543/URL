using System.Collections;
using TMPro;
using UnityEngine;

public class TutorialDescription : MonoBehaviour
{
    TextMeshProUGUI text;
    string[] textSequence;

    int sequenceIndex;

    private void Awake()
    {
        TutorialManager.instance.OnNewTask += UpdateText;
        text = GetComponent<TextMeshProUGUI>();
    }

    void UpdateText()
    {
        textSequence = TutorialManager.instance.CurrentTask.dialogue;
        StopAllCoroutines();
        StartCoroutine(ScrollText());
    }

    string colour = "";

    private IEnumerator ScrollText()
    {
        sequenceIndex = 0;
        

        while (sequenceIndex < textSequence.Length)
        {
            text.text = "";
            int currentChar = 0;
            int targetLength = textSequence[sequenceIndex].Length;

            while (currentChar < targetLength)
            {
                char toAdd = textSequence[sequenceIndex][currentChar];
                
                if(!ChangeColour(toAdd))
                {
                    if (colour != "")
                        text.text += "<color=" + colour + ">" + toAdd + "</color>";
                    else
                        text.text += toAdd;
                }

                currentChar++;

                yield return new WaitForSeconds(TutorialManager.instance.taskComplete ? 0.01f : 0.05f);
                continue;
            }

            yield return new WaitForSeconds(2f);
            sequenceIndex++;
        }

        TutorialManager.instance.DialogueFinished();
    }

    bool ChangeColour(char c)
    {
        switch (c){
            case '=':
                SetColourString("green");
                break;
            case '#':
                SetColourString("red");
                break;
            case '|':
                SetColourString("#00ccff");
                break;
            case '*':
                SetColourString("#ffff45");
                break;

            default:
                return false;
        }

        return true;
    }

    void SetColourString(string newColour)
    {
        if (colour.Length > 0)
        {
            colour = "";
            return;
        }

        colour = newColour;
    }
}
