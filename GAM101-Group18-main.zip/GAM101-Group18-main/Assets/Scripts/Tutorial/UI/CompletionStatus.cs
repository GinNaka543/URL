using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class CompletionStatus : MonoBehaviour
{
    private void Awake()
    {
        TutorialManager.instance.UpdateCompletionText = UpdateText;
        TutorialManager.instance.HideCompletionText = HideText;
    }

    void UpdateText(string text)
    {
        transform.parent.gameObject.SetActive(true);
        GetComponent<TextMeshProUGUI>().text = text;
    }

    void HideText()
    {
        transform.parent.gameObject.SetActive(false);
    }
}
