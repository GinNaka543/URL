using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TutorialTitle : MonoBehaviour
{
    private void Awake()
    {
        TutorialManager.instance.OnNewTask += UpdateText;
    }

    void UpdateText()
    {
        GetComponent<TextMeshProUGUI>().text = TutorialManager.instance.CurrentTask.title;
    }
}
