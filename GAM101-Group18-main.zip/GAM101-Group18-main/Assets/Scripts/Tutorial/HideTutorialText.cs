using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideTutorialText : MonoBehaviour
{
    void Start()
    {
        TutorialManager.instance.OnTutorialFinish += delegate { gameObject.SetActive(false); };
    }
}
