using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "CameraMovement", menuName = "ScriptableObjects/TutorialTasks/CameraMovement", order = 1)]
public class CameraMovementTask : TutorialTaskBothPlayers
{
    protected override void AssignDelegates(PlayerController player)
    {
        player.Rotating += delegate { CheckSuccess(player); };
    }
}
