using System;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "WaitForDialogue", menuName = "ScriptableObjects/TutorialTasks/WaitForDialogue", order = 1)]
public class WaitForDialogue : TutorialTask
{
    public override void OnCreation()
    {
        TutorialManager.instance.OnDialogueFinished += CompleteTask;
        TutorialManager.instance.HideCompletionText();
        //huh
    }

    private void CompleteTask()
    {
        TutorialManager.instance.OnDialogueFinished -= CompleteTask;
        OnCompletion();
    }
}
