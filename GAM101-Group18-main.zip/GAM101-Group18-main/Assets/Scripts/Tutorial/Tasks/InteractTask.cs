using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Interact", menuName = "ScriptableObjects/TutorialTasks/Interact", order = 1)]
public class InteractTask : TutorialTaskBothPlayers
{
    protected override void AssignDelegates(PlayerController player)
    {
        if(player.HeldObject != null)
        {
            CheckSuccess(player);
            return;
        }

        player.OnInteract += delegate { CheckSuccess(player); };
    }
}
