using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Jump", menuName = "ScriptableObjects/TutorialTasks/Jump", order = 1)]
public class JumpTask : TutorialTaskBothPlayers
{
    protected override void AssignDelegates(PlayerController player)
    {
        player.Jumped += delegate { CheckSuccess(player); };
    }
}
