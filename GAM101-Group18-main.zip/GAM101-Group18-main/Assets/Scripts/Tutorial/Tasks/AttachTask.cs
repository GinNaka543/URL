using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Attach", menuName = "ScriptableObjects/TutorialTasks/Attach", order = 1)]
public class AttachTask : TutorialTaskBothPlayers
{
    protected override void AssignDelegates(PlayerController player)
    {
        foreach(var slot in player.partSlots)
        {
            if(slot.contents as ArmPart)
            {
                CheckSuccess(player);
                return;
            }
        }

        player.OnItemEquipped += delegate { CheckSuccess(player); };
    }
}
