using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Reviving", menuName = "ScriptableObjects/TutorialTasks/Reviving", order = 1)]
public class RevivingTask : TutorialTask
{
    public override void OnCreation()
    {
        TutorialManager.instance.UpdateCompletionText("0/1");
        bool firstPlayer = true;
        foreach(GameObject player in PlayerManager.instance.players)
        {
            ObjectHealth health = player.GetComponent<ObjectHealth>();
            if (firstPlayer)
            {
                if (!PlayerManager.instance.players.Find(x => x != player).GetComponent<ObjectHealth>().IsDead)
                    health.Damage(999);

                health.OnRevive += delegate { TutorialManager.instance.UpdateCompletionText("1/1"); OnCompletion(); };
                firstPlayer = false;
            }
            else
            {
                if(health.Health >= health.MaxHealth)
                    health.Damage(health.Health / 2);
            }
        }
    }
}
