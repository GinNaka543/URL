using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Healing", menuName = "ScriptableObjects/TutorialTasks/Healing", order = 1)]
public class HealingTask : TutorialTaskBothPlayers
{
    protected override void AssignDelegates(PlayerController player)
    {
        if(player.health.Health >= player.health.MaxHealth - player.health.Degradation)
        {
            CheckSuccess(player);
            return;
        }

        player.health.OnHealthChanged += delegate
            {
                if (player.health.Health >= player.health.MaxHealth - player.health.Degradation)
                    CheckSuccess(player);
            };
    }
}
