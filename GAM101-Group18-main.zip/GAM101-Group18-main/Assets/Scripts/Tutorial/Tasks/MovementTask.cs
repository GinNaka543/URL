using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Movement", menuName = "ScriptableObjects/TutorialTasks/Movement", order = 1)]
public class MovementTask : TutorialTaskBothPlayers
{
    protected override void AssignDelegates(PlayerController player)
    {
        player.Moving += delegate { CheckSuccess(player); };
    }
}
