using System;
using UnityEngine;

[Serializable]
[CreateAssetMenu(fileName = "Combat", menuName = "ScriptableObjects/TutorialTasks/Combat", order = 1)]
public class CombatTask : TutorialTask
{
    const int enemyAmount = 3;
    int defeatedEnemies;

    public override void OnCreation()
    {
        LightMovement.SetLights(true);

        TutorialManager.instance.UpdateCompletionText("0/" + enemyAmount);
        for(int i = 0; i < enemyAmount; i++)
        {
            var enemy = Instantiate(Resources.Load<GameObject>("Tutorial/Enemies/EnemyNoWeapon"));

            enemy.GetComponentInChildren<Rigidbody>().MovePosition(EnemySpawnTutorial.Position);
            enemy.GetComponentInChildren<ObjectHealth>().OnDeath += delegate 
                { 
                    defeatedEnemies++;
                    TutorialManager.instance.UpdateCompletionText(defeatedEnemies + "/" + enemyAmount);

                    if(defeatedEnemies >= enemyAmount)
                    {
                        LightMovement.SetLights(false);
                        OnCompletion();
                    }
                };
        }
    }
}
