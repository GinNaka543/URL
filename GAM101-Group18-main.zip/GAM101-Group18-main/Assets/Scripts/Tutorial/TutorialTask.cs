using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public abstract class TutorialTask : ScriptableObject
{
    public virtual void OnCreation() { }
    protected void OnCompletion() 
    {
        TutorialManager.instance.NextTask(); 
        Destroy(this);
    }
}

public abstract class TutorialTaskBothPlayers : TutorialTask
{
    List<PlayerController> successfulPlayers = new();

    public override void OnCreation()
    {
        TutorialManager.instance.UpdateCompletionText("0/2");
        foreach (var player in PlayerManager.instance.players)
        {
            AssignDelegates(player.GetComponent<PlayerController>());
        }
    }

    protected void CheckSuccess(PlayerController player)
    {
        if (!successfulPlayers.Contains(player))
        {
            successfulPlayers.Add(player);
            TutorialManager.instance.UpdateCompletionText(successfulPlayers.Count + "/" + PlayerManager.instance.players.Count);
            if (successfulPlayers.Count >= PlayerManager.instance.players.Count)
            {
                OnCompletion();
            }
        }
    }

    protected virtual void AssignDelegates(PlayerController player)
    {
        //player.Jumped += delegate { CheckSuccess(player); };
    }
}
