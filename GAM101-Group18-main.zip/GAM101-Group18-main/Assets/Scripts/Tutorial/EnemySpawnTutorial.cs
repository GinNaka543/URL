using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnTutorial : MonoBehaviour
{
    public static Vector3 Position => position;
    static Vector3 position;

    private void Awake()
    {
        position = transform.position;
    }
}
