using UnityEngine;
using UnityEngine.UI;

public class WeaponImage : MonoBehaviour
{
    [SerializeField] bool isLeftArm;
    public bool IsLeftArm { get { return isLeftArm; } }

    public void UpdateImage(string imageName)
    {
        Image image = GetComponent<Image>();
        Sprite sprite = Resources.Load<Sprite>("Sprites/WeaponImage/" + imageName);

        image.enabled = sprite;
        if(sprite)
            image.sprite = sprite;
    }

    public static WeaponImage GetAssignedText(ArmPart arm)
    {
        return arm.Slot.Owner.GetComponent<HUDManager>().weaponNames[(arm.Slot as ArmSlot).isLeft ? 0 : 1];
    }
}
