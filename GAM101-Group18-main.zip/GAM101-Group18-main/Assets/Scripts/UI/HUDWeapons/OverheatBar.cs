using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OverheatBar : MonoBehaviour
{
    [SerializeField] bool isLeftArm;
    public bool IsLeftArm { get { return isLeftArm; } }

    public void UpdateBar(float cooldownAmount, float maxCooldown)
    {
        GetComponent<Image>().fillAmount = cooldownAmount / maxCooldown;
    }

    public void OnOverheatChanged(bool overheated)
    {
        if(overheated)
        {
            GetComponent<Image>().color = Color.red;
        }
        else
        {
            GetComponent<Image>().color = new Color(0,7f,0.5f);
        }
    }
}
