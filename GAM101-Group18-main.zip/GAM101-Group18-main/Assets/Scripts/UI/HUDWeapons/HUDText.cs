using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;

public class HUDText : MonoBehaviour
{
    [SerializeField] bool isLeftArm;
    public bool IsLeftArm { get { return isLeftArm; } }

    public void UpdateText(string text)
    {
        GetComponent<TextMeshProUGUI>().text = text;
    }

    public static HUDText GetAssignedText(ArmPart arm)
    {
        return arm.Slot.Owner.GetComponent<HUDManager>().hudText.Where(bar => bar.IsLeftArm == (arm.Slot as ArmSlot).isLeft).ElementAt(0);
    }
}
