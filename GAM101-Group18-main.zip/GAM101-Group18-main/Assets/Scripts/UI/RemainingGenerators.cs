using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class RemainingGenerators : MonoBehaviour
{
    void Awake()
    {
        AIManager.instance.OnGeneratorsChanged += UpdateText;
    }

    private void UpdateText(int Amount)
    {
        GetComponent<TextMeshProUGUI>().text = "Generators Remaining: " + Amount;
    }

    private void OnDestroy()
    {
        AIManager.instance.OnGeneratorsChanged -= UpdateText;
    }
}
