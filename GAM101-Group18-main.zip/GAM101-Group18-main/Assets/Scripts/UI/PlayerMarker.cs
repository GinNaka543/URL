using System.Collections;
using UnityEngine;

public class PlayerMarker : MonoBehaviour
{
    protected int playerID;

    private void Start()
    {
        StartCoroutine(ChangeVisibility());
        playerID = GetComponentInParent<PlayerController>().PlayerID;
    }

    IEnumerator ChangeVisibility()
    {
        yield return null;

        
        while (true)
        {
            GetComponent<SpriteRenderer>().enabled = GetNewVisibility(playerID);

            yield return new WaitForSeconds(0.1f);
        }
    }

    int Mask { get { return ~(1 << LayerMask.NameToLayer("EquipSlot") | 1 << LayerMask.NameToLayer("Ignore Raycast") | 1 << LayerMask.NameToLayer("IgnoreMovement") | 1 << LayerMask.NameToLayer("GrabHitbox") | 1 << LayerMask.NameToLayer("Bullet") | 1 << LayerMask.NameToLayer("Player1") | 1 << LayerMask.NameToLayer("Player2")); } }

    bool GetNewVisibility(int playerID)
    {
        GameObject otherPlayer = PlayerManager.instance.GetOtherPlayer(playerID);
        if (Physics.Raycast(transform.position,
            Vector3.Normalize(
                otherPlayer.transform.position - transform.position
                ), out var hit, Mathf.Infinity ,Mask))
        {
            return AdditionalCondition(hit, otherPlayer);
        }

        return true;
    }

    protected virtual bool AdditionalCondition(RaycastHit hit, GameObject otherPlayer)
    {
        Debug.DrawLine(transform.position, hit.point);
        return !(hit.transform.gameObject == otherPlayer);
    }
}
