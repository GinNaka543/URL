using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ShowItemDesc : MonoBehaviour
{
    public void ShowDescription(Interactable.ItemDisplayInfo info)
    {
        transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = info.name;
        transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = info.desc;
    }
}
