using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindUpMarker : PlayerMarker
{
    protected override bool AdditionalCondition(RaycastHit hit, GameObject otherPlayer)
    {
        return PlayerManager.instance.players.Find(x => x.GetComponent<PlayerController>().PlayerID == playerID).GetComponent<ObjectHealth>().IsDead && !GetComponentInParent<WindUp>().HeldBy;
    }
}
