using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GameOver : MonoBehaviour
{
    private void Awake()
    {
        gameObject.SetActive(false);
        GetComponentInParent<ObjectHealth>().OnDeath += OnDeath;
        GetComponentInParent<ObjectHealth>().OnRevive += OnRevive;
    }

    private void OnDeath()
    {
        gameObject.SetActive(true);
    }

    private void OnRevive()
    {
        gameObject.SetActive(false);
    }
}
