using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class Crosshair : MonoBehaviour
{
    PlayerController playerController;
    Color HighlightColour => new Color(0.9f, 0.9f, 0.9f, 0);

    private void Start()
    {
        playerController = GetComponentInParent<PlayerController>();
        StartCoroutine(UpdateCrosshair());
    }

    private IEnumerator UpdateCrosshair()
    {
        Camera camera = GetComponentInParent<PlayerController>().PlayerCamera;
        ShowItemDesc itemDesc = transform.parent.GetComponentInChildren<ShowItemDesc>();

        List<Material> lastMaterials = new();

        while (true)
        {
            Interactable interactable = IsInteractable(camera);

            if (interactable && interactable.CanHighlight(playerController))
            {
                if(interactable.Info != null)
                {
                    itemDesc.ShowDescription(interactable.Info);
                }
                
                Renderer[] currentMaterials = interactable.GetComponentsInChildren<Renderer>();
                if (currentMaterials.Length > 0)
                {
                    List<Material> materials = new();
                    foreach (Renderer renderer in currentMaterials)
                    {
                        materials.Add(renderer.material);
                    }

                    HighlightMaterials(materials, true);
                    HighlightMaterials(lastMaterials, false);
                    lastMaterials = materials;
                }
            }
            else
            {
                HighlightMaterials(lastMaterials, false);
                lastMaterials = new();
            }

            itemDesc.gameObject.SetActive(interactable && interactable.Info != null && interactable.CanHighlight(playerController));

            yield return new WaitForSeconds(0.1f);
        }
    }

    private void HighlightMaterials(List<Material> materials, bool highlight)
    {
        foreach(Material material in materials)
        {
            material.color += HighlightColour * (highlight ? 1 : -1);
        }
    }

    private Interactable IsInteractable(Camera camera)
    {
        var hits = Physics.RaycastAll(camera.transform.position, camera.transform.forward, 3f, 
                ~(1 << LayerMask.NameToLayer("EquipSlot") | (1 << LayerMask.NameToLayer("Ignore Raycast"))))
                .OrderBy(x => Vector3.Distance(x.point, camera.transform.position));
        
        foreach (var hit in hits)
        {
            Interactable interactable = hit.transform.GetComponentInParent<Interactable>();
            if (interactable)
            {
                if (interactable as Part)
                {
                    var part = interactable as Part;

                    if (part.Slot && part.Slot.Owner == playerController)
                        continue;
                }

                return interactable;
            }
            else
                break;
        }

        return null;
    }
}
