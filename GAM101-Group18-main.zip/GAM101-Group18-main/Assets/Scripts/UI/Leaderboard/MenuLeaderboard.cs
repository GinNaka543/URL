using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class MenuLeaderboard : MonoBehaviour
{
    [SerializeField] int leaderboardElements = 6;
    [SerializeField] int leaderboardOffset = -25;
    [SerializeField] int leaderboardSpacing = -40;

    private void Awake() 
    {
        CreateLeaderboard();
    }

    private void CreateLeaderboard()
    {
        string[] leaderboardData = new string[0];

        bool isData = PlayerPrefs.HasKey("Scores");
        if(isData)
             leaderboardData = PlayerPrefs.GetString("Scores").Split('|');

        for (int i = 0; i < leaderboardElements; i++) 
        {
            GameObject newElement = Instantiate(Resources.Load<GameObject>("UI/Leaderboard/LeaderboardElement"), transform);
            newElement.GetComponent<RectTransform>().anchoredPosition = new Vector3(0, leaderboardOffset + leaderboardSpacing * i);

            if (i < leaderboardData.Length && isData)
            {
                string[] playerData = leaderboardData[i].Split('~');
                newElement.GetComponentInChildren<PlayerName>().GetComponent<TextMeshProUGUI>().text = playerData[0];

                TextMeshProUGUI text = newElement.GetComponentInChildren<PlayerTime>().GetComponent<TextMeshProUGUI>();
                text.text = SpeedrunText.FormatTime(float.Parse(playerData[1]), text.fontSize);
            }
            else
            {
                newElement.transform.GetChild(0).gameObject.SetActive(false);
            }
        }
    }
}
