using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DamageFlash : MonoBehaviour
{
    private void Start()
    {
        GetComponentInParent<ObjectHealth>().OnDamaged += StartFlash;
    }

    private void StartFlash()
    {
        StopCoroutine(Flash());
        StartCoroutine(Flash());
    }

    const float fadeSpeed = 2.0f;

    private IEnumerator Flash()
    {
        Image UIFlash = GetComponent<Image>();
        UIFlash.color = new Color(0.6f, 0, 0, 0.6f); 
        while(UIFlash.color.a > 0)
        {
            UIFlash.color -= new Color(0,0,0, Time.deltaTime * fadeSpeed);
            yield return null;
        }
    }
}
