using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloseInfo : MonoBehaviour
{
    public void CloseInfoScreen()
    {
        Destroy(gameObject);
    }
}
