using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class Billboard : MonoBehaviour
{
    public static Billboard CreateBillboard(Texture2D texture, Vector3 position, string player = "", float scale = 1)
    {
        Billboard billboard = (Instantiate(Resources.Load("Entities/Billboard")) as GameObject).GetComponent<Billboard>();
        billboard.gameObject.layer = LayerMask.NameToLayer("Overlay" + player);
        billboard.GetComponent<SpriteRenderer>().sprite = Sprite.Create(texture, new Rect(0, 0, texture.width, texture.height), new Vector2(0.5f,0.5f));
        billboard.transform.position = position;
        billboard.transform.localScale = Vector3.one * scale;
        return billboard;
    }

    private void OnEnable()
    {
        RenderPipelineManager.beginCameraRendering += FaceCamera;
    }

    private void OnDisable()
    {
        RenderPipelineManager.beginCameraRendering -= FaceCamera;
    }

    private void FaceCamera(ScriptableRenderContext context, Camera camera)
    {
        transform.rotation = camera.transform.rotation;
    }
}
