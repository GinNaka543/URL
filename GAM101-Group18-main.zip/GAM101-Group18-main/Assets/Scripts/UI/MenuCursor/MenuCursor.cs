using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class MenuCursor : MonoBehaviour
{
    public static void CreateCursor(int controllerID)
    {
        var cursor = Instantiate(Resources.Load<GameObject>("UI/MenuCursor/Cursor"), CursorManager.instance.transform);
        var cursorComp = cursor.GetComponent<MenuCursor>();
            
        cursorComp.cursorID = controllerID;

        cursorComp.transform.GetChild(0).GetComponent<Image>().sprite = Resources.Load<Sprite>("Sprites/PlayerIcons/" + (controllerID == 0 ? "Small" : "Long") + "HeadImage");
    }

    int cursorID;

    private void Awake()
    {
        InputManager.instance.ControllersDisconnected += OnDisconnect;
    }

    void OnDisconnect()
    {
        Destroy(gameObject);
    }

    private void OnDestroy()
    {
        InputManager.instance.ControllersDisconnected -= OnDisconnect;
    }

    private void Update()
    {
        Movement();
        Click();

        if (pressCooldown >= 0)
            pressCooldown -= Time.deltaTime;

        if (pressed)
            pressedTime += Time.deltaTime;
        else 
        {
            pressedTime = 0;
            pressCooldown = pressCooldownStart;
        }
    }

    private void Click()
    {
        var results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(new PointerEventData(EventSystem.current) {position = transform.position}, results);
        results.OrderBy(x => x.depth);

        foreach(var result in results)
        {
            if (result.gameObject.GetComponentInParent<MenuCursor>() || result.gameObject.GetComponent<TextMeshProUGUI>())
                continue;

            if (TriggerButton(result.gameObject.GetComponent<Button>(), new PointerEventData(EventSystem.current))) return;
            if(TriggerSlider(result.gameObject.GetComponentInParent<Slider>())) return;

            return;
        }
    }

    bool pressed;

    float pressedTime;

    float pressCooldown;
    const float pressCooldownStart = .5f;

    Button lastHoveredButton;

    private bool TriggerButton(Button button, PointerEventData pointer)
    {
        if (button)
        {
            button.OnPointerEnter(pointer);
            lastHoveredButton = button;
        }

        if(button != lastHoveredButton) 
        {
            lastHoveredButton.OnPointerUp(pointer);
            lastHoveredButton.OnPointerExit(pointer);
        }

        if (InputManager.instance.usedGamepads[cursorID].buttonSouth.value > 0.9f)
        {
            if (button && button.GetComponent<HoldButton>() && pressCooldown <= 0)
            {
                pressed = true;
                button.onClick.Invoke();
                button.OnPointerDown(pointer);
                pressCooldown = pressCooldownStart - (pressedTime > 3f ? 0.4f:0);
                return true;
            }

            if (!pressed) { 
                pressed = true;
                if (button)
                {
                    button.onClick.Invoke();
                    button.OnPointerDown(pointer);
                    return true;
                }
            }
        }
        else
        {
            if(button)
                button.OnPointerUp(pointer);
            pressed = false;
        }

                
        return false;
    }

    private bool TriggerSlider(Slider slider)
    {
        if (slider)
        {
            if (InputManager.instance.usedGamepads[cursorID].buttonEast.value > 0.9f)
            {
                slider.value -= Time.unscaledDeltaTime;
                return true;
            }
            else if (InputManager.instance.usedGamepads[cursorID].buttonSouth.value > 0.9f)
            {
                slider.value += Time.unscaledDeltaTime;
                return true;
            }
        }
        return false;

    }


    const float cursorSpeed = 700f;

    private void Movement()
    {
        var dir = cursorSpeed * Time.unscaledDeltaTime *
            Vector3.Normalize(InputManager.instance.usedGamepads[cursorID].leftStick.value + InputManager.instance.usedGamepads[cursorID].rightStick.value);
        Vector3 intendedPosition = transform.position + (dir);

        var bounds = CursorManager.instance.GetComponent<RectTransform>().rect;

        if (intendedPosition.x > 0 && intendedPosition.x < bounds.width)
        {
            transform.position += new Vector3(dir.x, 0);
        }

        if (intendedPosition.y > 0 && intendedPosition.y < bounds.height)
        {
            transform.position += new Vector3(0, dir.y);
        }
    }
}
