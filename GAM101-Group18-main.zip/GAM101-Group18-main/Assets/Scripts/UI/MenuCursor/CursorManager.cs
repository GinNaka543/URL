using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorManager : MonoBehaviour
{
    public static CursorManager instance;

    private void Awake()
    {
        instance = this;

        if(InputManager.instance.ControllersAreConnected)
            CreateCursors();

        InputManager.instance.ControllersConnected += CreateCursors;
    }
    
    private void CreateCursors()
    {
        int id = 0;
        foreach (var borb in InputManager.instance.usedGamepads)
        {
            if (borb != null)
            {
                MenuCursor.CreateCursor(id);
            }
            id++;
        }
    }

    private void OnDestroy()
    {
        InputManager.instance.ControllersConnected -= CreateCursors;
        instance = null;
    }

    public static void CreateCursorManager()
    {
        if (instance)
            Destroy(instance.gameObject);

        Instantiate(Resources.Load("UI/MenuCursor/CursorCanvas"));
    }
}
