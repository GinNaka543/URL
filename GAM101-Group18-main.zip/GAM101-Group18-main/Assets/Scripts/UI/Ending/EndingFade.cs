using UnityEngine;
using UnityEngine.UI;

public class EndingFade : MonoBehaviour
{
    const float fadeStart = 5f;
    float fade = fadeStart;

    public delegate void EndingFadeEnd();
    public EndingFadeEnd OnEndingFadeEnd;

    Image image;

    private void Awake()
    {
        image = GetComponent<Image>();
        image.color = new Color(1,1,1,0);
    }

    private void Update()
    {
        fade -= Time.unscaledDeltaTime;
        image.color = new(1,1,1,1 - fade / fadeStart);

        if(fade <= 0)
        {
            OnEndingFadeEnd?.Invoke();
            Destroy(this);
        }
    }
}
