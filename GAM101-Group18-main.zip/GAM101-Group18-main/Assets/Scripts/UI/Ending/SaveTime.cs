using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SaveTime : MonoBehaviour
{
    public string TeamName
    {
        get => teamName;
        set
        {
            if(value.Length < 8)
                teamName = value;
            OnNameUpdated?.Invoke();
        }
    }
    string teamName = "";
    [SerializeField] int leaderboardLimit = 6;

    //String format: name~time|name~time|

    public delegate void SaveVoidDelegate();
    public event SaveVoidDelegate OnScoreSaved;
    public event SaveVoidDelegate OnNameUpdated;

    int insertIndex = 0;

    bool isData;

    List<string> teams = new();

    private void Start()
    {
        isData = PlayerPrefs.HasKey("Scores");
        if (!isData)
        {
            CreateKeyboard();
            return;
        }

        teams = PlayerPrefs.GetString("Scores").Split('|').ToList();

        for (int i = 0; i < teams.Count; i++)
        {
            float teamTime = float.Parse(teams[i].Split('~')[1]);
            if (teamTime > ScoreManager.Instance.CurrentTime)
            {
                break;
            }

            insertIndex++;
        }

        if (insertIndex >= teams.Count)
            gameObject.SetActive(false);
        else
            CreateKeyboard();
    }

    public void OnSave()
    {
        string finalScores = "";
        teams.Insert(insertIndex, teamName + "~" + ScoreManager.Instance.CurrentTime.ToString());

        for (int i = 0; i < leaderboardLimit && i < teams.Count; i++)
        {
            if (i != 0)
                finalScores += "|";

            finalScores += teams[i];
        }

        PlayerPrefs.SetString("Scores", finalScores);
        PlayerPrefs.Save();
        OnScoreSaved?.Invoke();
    }

    const string keyboardLayout = "qwertyuiop,asdfghjkl,zxcvbnm";
    [SerializeField] int keyboardOffset = 25;
    [SerializeField] int keyboardOffsetHorizontal = 45;
    [SerializeField] int keyboardSpacing = 120;

    private void CreateKeyboard()
    {
        string[] keyboardRows = keyboardLayout.Split(',');

        int rows = 0;
        foreach(string row in keyboardRows)
        {
            int characters = 0;
            foreach(char character in row)
            {
                GameObject button = Instantiate(Resources.Load<GameObject>("UI/KeyboardButton"), transform);

                button.GetComponent<RectTransform>().anchoredPosition = new Vector2(keyboardOffsetHorizontal + ((-(row.Length / 2f) + characters) * keyboardSpacing), keyboardOffset - (rows * keyboardSpacing));

                button.GetComponentInChildren<TextMeshProUGUI>().text = character.ToString();
                button.GetComponentInChildren<Button>().onClick.AddListener
                    (delegate 
                    { 
                        TeamName += character; 
                    });

                characters++;
            }
            rows++;
        }
    }

    public void RemoveCharacter()
    {
        if(TeamName.Length > 0)
            TeamName = TeamName.Substring(0, TeamName.Length - 1);
    }
}
