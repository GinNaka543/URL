using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class SpeedrunText : MonoBehaviour
{
    float finalValue;

    private void Start()
    {
        if (ScoreManager.Instance)
        {
            finalValue = ScoreManager.Instance.EndRun();
            GetComponent<TextMeshProUGUI>().text = FormatTime(finalValue, GetComponent<TextMeshProUGUI>().fontSize);

            Destroy(ScoreManager.Instance.gameObject);
        }
    }

    public static string FormatTime(float time, float fontSize)
    {
         return ToTimeValue((time / 60) / 60) + ":"
              + ToTimeValue(time / 60) + ":"
              + ToTimeValue(time % 60)
              + "<size=" + (int)(fontSize / 1.5) + ">."
              + ToTimeValue(time * 100) + "</size>";
    }

    static private string ToTimeValue(float timeValue)
    {
        string time = Mathf.Floor(timeValue).ToString();

        if (time.Length < 2)
            time = "0" + time;

        if (time.Length > 2)
            time = time.Substring(time.Length-2);

        return time;
    }
}
