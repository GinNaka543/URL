using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndingMenu : MonoBehaviour
{
    private void Awake()
    {
        CursorManager.CreateCursorManager();
    }
}
