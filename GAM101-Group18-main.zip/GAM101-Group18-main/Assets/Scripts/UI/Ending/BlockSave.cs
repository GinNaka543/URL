using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockSave : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<SaveTime>().OnNameUpdated += CheckCharacters;
        gameObject.SetActive(true);
    }

    private void CheckCharacters()
    {
        gameObject.SetActive(!(GetComponentInParent<SaveTime>().TeamName.Length > 0));
    }
}
