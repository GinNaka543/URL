using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class EndingUI : MonoBehaviour
{
    EndingMenu endingMenu;

    private void Start()
    {
        endingMenu = GetComponentInChildren<EndingMenu>();

        GetComponentInChildren<EndingFade>().OnEndingFadeEnd = 
            delegate 
            { 
                endingMenu.gameObject.SetActive(true);
                Cursor.lockState = CursorLockMode.Confined;
                Cursor.visible = true;
                Time.timeScale = 0f;
            };
        endingMenu.gameObject.SetActive(false);
    }
}
