using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockName : MonoBehaviour
{
    [SerializeField]
    bool startInactive;

    private void Awake()
    {
        GetComponentInParent<SaveTime>().OnScoreSaved += DisableButton;

        gameObject.SetActive(!startInactive);
    }

    private void DisableButton()
    {
        gameObject.SetActive(true);
    }
}
