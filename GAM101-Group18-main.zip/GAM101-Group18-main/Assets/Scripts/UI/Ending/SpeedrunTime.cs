using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedrunTime : MonoBehaviour
{
    private void Awake()
    {
        if (!ScoreManager.Instance)
            gameObject.SetActive(false);
    }
}
