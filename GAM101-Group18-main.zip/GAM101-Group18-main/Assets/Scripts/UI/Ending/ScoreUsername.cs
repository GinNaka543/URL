using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreUsername : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<SaveTime>().OnNameUpdated += UpdateName;
    }

    private void UpdateName()
    {
        GetComponent<TextMeshProUGUI>().text = GetComponentInParent<SaveTime>().TeamName;
    }
}
