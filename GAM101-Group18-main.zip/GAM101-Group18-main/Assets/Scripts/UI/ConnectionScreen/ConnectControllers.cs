using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class ConnectControllers : MonoBehaviour
{
    public delegate void connectedController(bool connected, bool isLeft, string joinText);
    public event connectedController ConnectedController;

    void Update()
    {
        CheckForConnection();
        ContinueGame();
    }

    float startCountdown = -1;

    public delegate void countdown(float time);
    public countdown Countdown;

    void ContinueGame()
    {
        if(startCountdown != -1)
        {
            if(startCountdown > 0)
            {
                startCountdown -= Time.unscaledDeltaTime;
                Countdown(startCountdown);
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }

    void CheckForConnection()
    {
        Gamepad current = Gamepad.current;
        if(current != null)
        {
            if (current.leftTrigger.wasPressedThisFrame)
            {
                ConnectController(0, current);
            }
            else if (current.rightTrigger.wasPressedThisFrame)
            {
                ConnectController(1, current);
            }
        }

        if (Input.GetMouseButtonDown(0))
        {
            ConnectController(0, null, true);
        }
        else if (Input.GetMouseButtonDown(1))
        {
            ConnectController(1, null, true);
        }
    }

    bool[] connected = new bool[2];

    void ConnectController(int id, Gamepad current, bool keyboard = false)
    {
        if (InputManager.instance.usedGamepads[id == 0 ? 1:0] != current || keyboard)
        {
            if(InputManager.instance.usedGamepads[id] != current && connected[id])
            {
                return;
            }
            InputManager.instance.usedGamepads[id] = InputManager.instance.usedGamepads[id] != current ? current : null;
            connected[id] = !connected[id];
            ConnectedController?.Invoke(connected[id], id == 0, keyboard ? "Keyboard" : current.name);
            ControllersConnected();
        }
    }

    public delegate void countdownVis(bool vis);
    public countdownVis CountdownVis;

    void ControllersConnected()
    {
        bool controllersConnected = true;
        for(int i = 0; i < InputManager.instance.usedGamepads.Length; i++)
        {
            if (!connected[i])
            {
                controllersConnected = false;
            }
        }

        if (controllersConnected)
        {
            CountdownVis(true);
            startCountdown = 3;
        }
        else
        {
            CountdownVis(false);
            startCountdown = -1;
        }
    }

    private void Awake()
    {
        InputManager.instance.isPaused = true;
        Time.timeScale = 0f;
    }

    private void OnDestroy()
    {
        InputManager.instance.isPaused = false;
        InputManager.instance.ControllersConnected?.Invoke();
        Time.timeScale = 1f;
    }
}
