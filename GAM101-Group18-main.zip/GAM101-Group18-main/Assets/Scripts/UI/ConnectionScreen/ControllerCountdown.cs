using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ControllerCountdown : MonoBehaviour
{
    private void Awake()
    {
        gameObject.SetActive(false);
        GetComponentInParent<ConnectControllers>().Countdown = OnCountdownChanged;
        GetComponentInParent<ConnectControllers>().CountdownVis = CountdownVisibility;
    }

    void OnCountdownChanged(float time)
    {
        GetComponent<TextMeshProUGUI>().text = Mathf.FloorToInt(time + 1).ToString();
    }

    void CountdownVisibility(bool visibilty)
    {
        gameObject.SetActive(visibilty);
    }
}
