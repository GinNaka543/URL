using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;

public class ConnectText : MonoBehaviour
{
    [SerializeField] bool isLeft;

    private void Awake()
    {
        GetComponentInParent<ConnectControllers>().ConnectedController += UpdateText;
    }

    private void UpdateText(bool connected, bool isLeft, string joinText)
    {
        if(isLeft == this.isLeft)
        {
            var text = GetComponent<TextMeshProUGUI>();
            if (connected)
            {
                text.text = joinText;
                text.color = new Color(0.2f,1,0.2f);
            }
            else
            {
                text.text = "Not Connected";
                text.color = new Color(1, 0.2f, 0.2f);
            }
        }
    }
}
