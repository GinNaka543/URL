using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class GraceTimer : MonoBehaviour
{
    private void Start()
    {
        AIManager.instance.showGraceTimer = ShowTime;
    }

    void ShowTime(float graceTimer)
    {
        GetComponent<TextMeshProUGUI>().text = Mathf.CeilToInt(graceTimer).ToString();
    }
}
