using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HideIfNoGenerator : MonoBehaviour
{
    void Start()
    {
        AIManager.instance.OnGeneratorsChanged += OnGeneratorsChanged;
        AIManager.instance.EnemySpawnChanged += OnEnemySpawnChanged;

        if (AIManager.instance.generators.Count <= 0 || !AIManager.instance.CanSpawnEnemies)
        {
            gameObject.SetActive(false);
        }
    }

    void OnGeneratorsChanged(int generators)
    {
        if(generators <= 0)
            gameObject.SetActive(false);
    }

    void OnEnemySpawnChanged(bool enemySpawning)
    {
        gameObject.SetActive(enemySpawning);
    }
}
