using UnityEngine.UI;

public class DegradationHUD : DegradationBar
{
    protected override void SetDegredationFill(float amount)
    {
        GetComponent<Image>().fillAmount = amount;
    }
}
