using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthbarHUD : Healthbar
{
    protected override void SetHealthbarFill(float amount)
    {
        GetComponent<Image>().fillAmount = amount;
    }
}
