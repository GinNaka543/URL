using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Healthbar : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<ObjectHealth>().OnHealthChanged += UpdateHealth;
    }

    private void UpdateHealth(ObjectHealth health)
    {
        SetHealthbarFill(Mathf.Clamp01((float)health.Health / health.MaxHealth));
    }

    protected virtual void SetHealthbarFill(float amount)
    {
        transform.localScale = new Vector3(amount, 1, 1);
    }
}
