using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DegradationBar : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<ObjectHealth>().OnDegradationChanged += UpdateDegradation;
    }

    private void UpdateDegradation(ObjectHealth health)
    {
        SetDegredationFill((float)health.Degradation / health.MaxHealth);
    }

    protected virtual void SetDegredationFill(float amount)
    {
        transform.localScale = new Vector3(amount, 1, 1);
    }
}
