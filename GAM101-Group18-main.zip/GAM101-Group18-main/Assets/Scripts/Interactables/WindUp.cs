using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindUp : Part
{
    PlayerController lastEquippedPlayer;

    public override ItemDisplayInfo Info => new("Key", "...Th3...key..t0...m!..l1f3");

    public override SlotTypes PartType { get { return SlotTypes.Wind; } }
    bool IsWinding 
    {
        get => isWinding;
        set
        {
            isWinding = value;
            if (!isWinding)
                windingSound.Stop();
        }
    }

    bool isWinding;

    public AudioSource windingSound;

    protected override void Start()
    {
        OnEquip += OnEquipped;
        OnRemove += OnRemoved;
        base.Start();
    }

    public override void Interact(PlayerController player)
    {
        if (Slot)
        {
            StartCoroutine(Wind());
        }
        else
        {
            base.Interact(player);
        }
    }

    public override void EndInteract(PlayerController player)
    {
        IsWinding = false;
    }

    const float windSpeed = 60;

    IEnumerator Wind()
    {
        float healCooldown = 0;

        IsWinding = true;
        while (IsWinding)
        {
            healCooldown -= Time.deltaTime;            

            if (healCooldown <= 0)
            {
                ObjectHealth targetHealth = GetComponentInParent<ObjectHealth>();
                if (!targetHealth)
                {
                    yield return null;
                    continue;
                }

                if (!targetHealth.Heal(5))
                {
                    IsWinding = false;
                }
                else
                {
                    if(!windingSound.isPlaying)
                        windingSound.Play();
                    targetHealth.DegredationCounter--;
                }
                healCooldown = 0.15f;
            }

            transform.rotation = Quaternion.Euler(new Vector3(0, 0, windSpeed * Time.deltaTime) + transform.eulerAngles);            
            yield return null;
        }
    }

    private void OnEquipped()
    {
        GetComponent<BoxCollider>().size = new Vector3(0.5f,0.5f, 0.7f);
        Slot.Owner.GetComponent<ObjectHealth>().OnDeath += OnOwnerDeath;
        gameObject.layer = LayerMask.NameToLayer("Player" + (slot.Owner.PlayerID + 1));
        lastEquippedPlayer = Slot.Owner;
    }

    private void OnRemoved()
    {
        GetComponent<BoxCollider>().size = new Vector3(0.5f, 0.1f, 0.7f);
        Slot.Owner.GetComponent<ObjectHealth>().OnDeath -= OnOwnerDeath;
    }

    private void OnOwnerDeath()
    {
        Disconnect();
        slot = null;
        OnDrop();
        rb.AddForce(transform.forward * -9, ForceMode.Impulse);
    }

    private void Update()
    {
        if(lastEquippedPlayer)
            if(Vector3.Distance(lastEquippedPlayer.transform.position, transform.position) > 250)
            {
                GetComponent<Rigidbody>().velocity = Vector3.zero;
                GetComponent<Rigidbody>().MovePosition(lastEquippedPlayer.transform.position + new Vector3(0,2));
            }
    }
}
