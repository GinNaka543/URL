using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTwoPickup : PlayerPickup
{
    public override ItemDisplayInfo Info => new("N", "N");
}
