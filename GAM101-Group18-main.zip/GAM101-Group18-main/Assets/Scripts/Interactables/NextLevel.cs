using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour
{
    public delegate void OpenDoorsDelegate();
    public static OpenDoorsDelegate OpenDoors;

    public AudioSource doorSound;

    [SerializeField] int forceLevel = -1;

    private void Awake()
    {
        OpenDoors += OpenDoor;
    }

    public bool isOpen;

    void OpenDoor()
    {
        isOpen = true;
        Billboard.CreateBillboard
            (
                Resources.Load<Texture2D>("Sprites/door-combined"), transform.position, "", 2
            );
    }

    private void OnCollisionEnter(Collision other)
    {
        //AIManager.instance.generators.Count > 0
        if (!isOpen)
        {
            return;
        }

        if (other.gameObject.GetComponent<PlayerController>())
        {
            Time.timeScale = 1.0f;
            SaveManager.instance.Save();

            if(forceLevel == -1)
                SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
            else
                SceneManager.LoadScene(forceLevel);
        }
        
    }

    private void OnDestroy()
    {
        OpenDoors -= OpenDoor;
    }

}
