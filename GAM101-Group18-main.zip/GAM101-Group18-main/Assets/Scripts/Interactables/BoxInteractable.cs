using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoxInteractable : Interactable
{
    public override ItemDisplayInfo Info => new("Box", "Shoot / Interact to open and find parts to upgrade with");

    public override void Interact(PlayerController player)
    {
        GetComponent<ObjectHealth>().Damage(999);
    }
}
