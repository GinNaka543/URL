using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pickup : Interactable
{
    public PlayerController HeldBy => heldBy;
    protected PlayerController heldBy;
    protected Rigidbody rb;

    protected virtual void Awake()
    {
        rb = GetComponent<Rigidbody>();
    }

    public override void Interact(PlayerController p)
    {
        if (heldBy)
        {
            heldBy.HeldObject = null;
        }

        heldBy = p;
        p.HeldObject = gameObject;
        rb.isKinematic = true;
        GetComponent<Collider>().isTrigger = true;
        gameObject.layer = LayerMask.NameToLayer("IgnoreMovement");
        StartCoroutine(Move());
    }

    public void Drop()
    {
        OnDrop(heldBy);
        heldBy = null;
    }

    protected virtual void OnDrop(PlayerController heldBy = null)
    {
        gameObject.layer = 0;
        rb.isKinematic = false;
        GetComponent<Collider>().isTrigger = false;
    }

    protected const float heldDistance = 1.2f;
    private IEnumerator Move()
    {
        while(heldBy)
        {
            WhileMoving();
            yield return null;
        }        
    }

    protected virtual void WhileMoving()
    {
        rb.MovePosition((heldBy.PlayerCamera.transform.forward * heldDistance) + heldBy.PlayerCamera.transform.position);
    }
}
