using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Thingy : Interactable
{
    public override void Interact(PlayerController player)
    {
        SaveManager.instance.Save();
        SceneManager.LoadScene(7);
    }
}
