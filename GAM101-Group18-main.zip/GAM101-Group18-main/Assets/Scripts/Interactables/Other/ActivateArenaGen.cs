using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class ActivateArenaGen : Interactable
{
    public override ItemDisplayInfo Info => new("Arena Generator","Press the interact button to start up the generator.");

    public override void Interact(PlayerController player)
    {
        AIManager.instance.CanSpawnEnemies = !AIManager.instance.CanSpawnEnemies;

        if (AIManager.instance.CanSpawnEnemies)
        {
            AIManager.instance.graceTimer = 5f;
            GetComponent<Generator>().canSpawnCooldown = 0f;
            AIManager.instance.alarms = true;
        }
        else
        {
            var health = GetComponent<ObjectHealth>();
            health.Heal(health.MaxHealth - health.Health);
            LightMovement.SetLights?.Invoke(false);
        }
    }
}
