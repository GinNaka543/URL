using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AscendingObject : Interactable
{
    bool interacting;

    public override bool CanHighlight(PlayerController observer)
    {
        return false;
    }

    public override void Interact(PlayerController player)
    {
        interacting = true;
    }

    public override void EndInteract(PlayerController player)
    {
        interacting = false;
    }

    private void Update()
    {
        if (interacting)
        {
            transform.position += new Vector3(0, 0, Time.deltaTime / 2);
        }
    }
}
