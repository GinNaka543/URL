using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Interactable : MonoBehaviour
{
    public abstract void Interact(PlayerController player);
    public virtual void EndInteract(PlayerController player) { }

    public virtual ItemDisplayInfo Info => null;

    public virtual bool CanHighlight(PlayerController observer) { return true; }


    public class ItemDisplayInfo
    {
        public ItemDisplayInfo(string name, string desc, string image = "") 
        {
            this.name = name;
            this.desc = desc;
            this.image = image;
        }

        public string name;
        public string desc;
        public string image;
    }
}
