using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPickup : Pickup
{
    public override ItemDisplayInfo Info => new("R", "R");

    public override bool CanHighlight(PlayerController observer)
    {
        return !(observer == GetComponent<PlayerController>());
    }

    public override void Interact(PlayerController p)
    {
        if (GetComponent<ObjectHealth>().IsDead)
        {
            base.Interact(p);
        }
    }
}
