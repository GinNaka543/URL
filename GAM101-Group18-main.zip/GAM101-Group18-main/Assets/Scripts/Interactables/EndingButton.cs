using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndingButton : Interactable
{
    Vector3 startPos;

    public override void Interact(PlayerController player)
    {
        if(!isPressed)
            EndingManager.instance.PressedButtons++;

        isPressed = true;
        unpressTime = unpressTimeStart;

        transform.position = startPos - new Vector3(0,0.05f,0);
    }

    const float unpressTimeStart = 0.3f;
    float unpressTime = unpressTimeStart;

    bool isPressed;

    private void Awake()
    {
        startPos = transform.position;
    }

    void Update()
    {
        if (!isPressed || EndingManager.instance.PressedButtons >= 2)
            return;

        unpressTime -= Time.deltaTime;
        if (unpressTime <= 0)
        {
            EndingManager.instance.PressedButtons--;
            isPressed = false;

            transform.position = startPos;
        }
    }
}
