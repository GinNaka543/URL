using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorOpen : MonoBehaviour
{
    Vector3 direction = new(0,1,0);
    [SerializeField] float maxheight = 7.8f;
    [SerializeField] float minheight = 3.65f;
    void Update()
    {
        bool playerIsNear = false;
        foreach (GameObject player in PlayerManager.instance.players)
        {
            if(Vector3.Distance(player.transform.position, transform.position) < 15f)
            {
                playerIsNear = true;
            }
        }

        if (playerIsNear)
        {
            if(transform.position.y < maxheight)
            {
                transform.position += direction * Time.deltaTime;
            }       
        }
        else
        {
            //Move down
            if (transform.position.y > minheight) 
            { 
                transform.position -= direction * Time.deltaTime;
            }
        }
    }
}
