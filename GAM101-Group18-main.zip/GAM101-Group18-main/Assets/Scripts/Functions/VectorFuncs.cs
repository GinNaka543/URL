using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class VectorFuncs
{
    public static Vector3 RemoveY(Vector3 vector, float y = 0)
    {
        return new Vector3(vector.x, y, vector.z);
    }

    public static float PathLength(Vector3[] points)
    {
        float totalDistance = 0;
        Vector3 previousPoint = new();

        bool firstLoop = true;

        foreach(Vector3 point in points)
        {
            if (!firstLoop)
            {
                totalDistance += Vector3.Distance(previousPoint, point);
            }
            previousPoint = point;
            firstLoop = false;
        }

        if (firstLoop)
        {
            return Mathf.Infinity;
        }

        return totalDistance;
    }
}
