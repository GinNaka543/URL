using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Face : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<ObjectHealth>().OnDeath += OnDeath;
        GetComponentInParent<ObjectHealth>().OnRevive += OnRevive;
    }

    private void OnDeath()
    {
        GetComponent<TextMeshPro>().text = "x_x";
    }

    private void OnRevive()
    {
        GetComponent<TextMeshPro>().text = "._.";
    }
}
