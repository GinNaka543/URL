using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeneratorHealing : MonoBehaviour
{
    private void Awake()
    {
        StartCoroutine(heal());
    }

    IEnumerator heal()
    {
        while (true)
        {
            foreach (Collider collider in Physics.OverlapSphere(transform.position, 15))
            {
                if (collider.GetComponent<EnemyController>())
                {
                    collider.GetComponent<ObjectHealth>().Heal(2);
                }
            }
            yield return new WaitForSeconds(0.25f);
        }
    }
}
