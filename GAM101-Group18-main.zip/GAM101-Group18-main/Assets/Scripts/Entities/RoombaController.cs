using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public class RoombaController : EnemyController
{
    protected override void Awake()
    {
        base.Awake();
        GetComponent<ObjectHealth>().OnDeath += RoombaExplodeThenICryBecauseTheRoombaExploded;
        updatePathByManager = false;
    }

    private void Start()
    {
        StartCoroutine(SpawnEffect());
    }

    const float growthRate = 5f; 

    private IEnumerator SpawnEffect()
    {
        Vector3 targetScale = transform.localScale;
        transform.localScale = targetScale * 0.1f;

        while(Vector3.Distance(targetScale, transform.localScale) > 0.01f)
        {
            transform.localScale += (targetScale - transform.localScale) * (Time.deltaTime * growthRate);
            yield return null;
        }
    }

    public void SetTarget()
    {
        target = AIManager.instance.ClosestEnemyInSight(transform.position);
        if (target)
        {
            target.GetComponent<EnemyController>().OnPathUpdate += StartPathUpdate;
        }
        else
        {
            path = new NavMeshPath();
        }
    }

    private void StartPathUpdate()
    {
        StartCoroutine(UpdatePath());
    }

    public override IEnumerator UpdatePath()
    {
        obstacle.enabled = false;
        yield return null;
        if (this)
        {
            if (!Target)
            {
                yield break;
            }
            NavMesh.CalculatePath(transform.position, Target.transform.position, NavMesh.AllAreas, path);

            //!!!!!!!!!!!!!!!!! SCP CODE !!!!!!!!!!!!!!!!!!!!!!! (Again...)

            //ITEM #: SCP-52 (Again...)
            //OBJECT CLASS: KETER (Again...)

            //Special Containment Procedures: Just don't delete this line of code (Again...)

            /* -> */for (int i = 0; i < path.corners.Length - 1; i++) Debug.DrawLine(path.corners[i], path.corners[i + 1], Color.red); /* <- (Again...)*/

            //This line of code is like the TF2 coconut.jpg dont delete it or else... (Again...)

            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! (Again...)
            targettedPoint = 0;
            obstacle.enabled = true;
        }
    }

    private void Update()
    {
        if (!Target || Target.GetComponent<RoombaController>())
        {
            SetTarget();
            return;
        }

        if(Vector3.Distance(transform.position, Target.transform.position) < 2f)
        {
            if (GetComponent<ObjectHealth>().IsDead)
            {
                return;
            }

            GetComponent<ObjectHealth>().Damage(999);
        }
    }

    const float explosionRadius = 3.5f;

    private void RoombaExplodeThenICryBecauseTheRoombaExploded()
    {
        Instantiate(Resources.Load("Entities/ExplosionKindOf") as GameObject).transform.position = transform.position;
        foreach(Collider collider in Physics.OverlapSphere(transform.position, explosionRadius))
        {
            if(collider.gameObject == gameObject)
            {
                continue;
            }

            if (collider.GetComponent<Rigidbody>()) 
                collider.GetComponent<Rigidbody>().AddExplosionForce(750f, transform.position, explosionRadius);

            if (PlayerPrefs.GetInt("FriendlyFire") != 1)
                if (collider.GetComponent<PlayerController>())
                    continue;

            if (collider.GetComponent<ObjectHealth>() && !collider.GetComponent<ObjectHealth>().IsDead)
            {
                collider.GetComponent<ObjectHealth>().Damage((int)(100 * (1 - Mathf.Min(Vector3.Distance(transform.position, collider.transform.position) / explosionRadius,1))));
            }
        }
    }

    private void OnDestroy()
    {
        if(target)
            target.GetComponent<EnemyController>().OnPathUpdate -= StartPathUpdate;
    }
}
