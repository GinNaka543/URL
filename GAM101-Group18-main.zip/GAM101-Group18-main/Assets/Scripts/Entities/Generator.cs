using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class Generator : MonoBehaviour
{
    public float canSpawnCooldown;

    private void Start()
    {
        AIManager.instance.AddGenerator(this);
        var health = GetComponent<ObjectHealth>();
        health.OnDeath += OnDeath;
        health.OnDamagedAmount += SkipGracePeriod;
    }

    public IEnumerator SpawnEnemy()
    {
        int attempts = 0;
        while (attempts < 20) {

            attempts++;
            yield return null;

            if (Physics.Raycast(transform.position + new Vector3(Random.Range(-4, 4), 1, Random.Range(-4, 4)), Vector3.down, out RaycastHit hit, Mathf.Infinity, 1 << LayerMask.NameToLayer("Default")))
            {
                if(hit.transform.gameObject == gameObject)
                {
                    continue;
                }

                if (Physics.OverlapCapsule(hit.point + new Vector3(0, .5f), hit.point + new Vector3(0, 1.5f), 0.48f).Length > 0)
                {
                    continue;
                }

                Object[] enemyTypes = Resources.LoadAll("Enemies");
                GameObject spawnedEnemy = Instantiate(enemyTypes[Random.Range(0, enemyTypes.Length)] as GameObject);

                spawnedEnemy.transform.position = hit.point;
                spawnedEnemy.GetComponentInChildren<Rigidbody>().MovePosition(spawnedEnemy.transform.position + new Vector3(0, 1f));
                yield break;
            }
        }
    }

    private void Update()
    {
        if(canSpawnCooldown > 0)
            canSpawnCooldown -= Time.deltaTime;
    }

    protected virtual void OnDeath()
    {
        Destroy(gameObject);
        AIManager.instance.RemoveGenerator(this);
    }

    protected void SkipGracePeriod(int amount)
    {
        var cooldownDecrease = amount * 0.02f;
        canSpawnCooldown -= cooldownDecrease;
        AIManager.instance.graceTimer -= cooldownDecrease;
    }
}
