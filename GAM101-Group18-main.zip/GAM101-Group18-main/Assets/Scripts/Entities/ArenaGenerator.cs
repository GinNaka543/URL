using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static ObjectHealth;

public class ArenaGenerator : Generator
{
    private void Awake()
    {
        GetComponent<ObjectHealth>().OnDamagedAmount += HealOnDamaged;
    }

    private void HealOnDamaged(int amount)
    {
        if(!AIManager.instance.CanSpawnEnemies)
            GetComponent<ObjectHealth>().Heal(amount);
    }

    protected override void OnDeath()
    {
        AIManager.instance.CanSpawnEnemies = false;
        var health = GetComponent<ObjectHealth>();
        health.Heal(health.MaxHealth - health.Health);
        AIManager.instance.CanSpawnEnemies = false;
    }
}
