using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConveyerMovement : MonoBehaviour
{
    //public GameObject belt;
    //public Transform endpoint;
    public float speed = 500f;
    public Vector3 ConveyDirection;

    public AudioSource beltSound;

    private void Awake()
    {
        beltSound = GetComponent<AudioSource>();
    }

    private void OnCollisionStay(Collision collisionInfo)
    {
        var other = collisionInfo.collider.GetComponent<Rigidbody>();
        if (other)
        {
            other.MovePosition(other.transform.position + speed * Time.deltaTime * ConveyDirection);
            
        }
        

        //other.transform.position //+= ConveyDirection * Time.deltaTime;Vector3.MoveTowards(other.transform.position, endpoint.position, speed * Time.deltaTime);

        //other.transform.position = Vector3.MoveTowards(other.transform.position, endpoint.position, speed * Time.deltaTime);


    }

    private void OnCollisionEnter(Collision collision)
    {
        beltSound.Play();
    }

    private void OnCollisionExit(Collision collision)
    {
        beltSound.Stop();
    }
}
