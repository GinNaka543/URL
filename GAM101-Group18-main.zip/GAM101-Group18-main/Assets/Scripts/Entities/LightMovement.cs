using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Experimental.GlobalIllumination;

public class LightMovement : MonoBehaviour
{
    // Maximum turn rate in degrees per second.
    [SerializeField]float turningRate = 100f;

    private AudioSource alarm;
    bool isActive;

    public delegate void LightsDelegate(bool newState);
    public static LightsDelegate SetLights;

    private void Awake()
    {
        alarm = transform.GetChild(0).gameObject.GetComponent<AudioSource>();
        SetLights += SetLight;
        gameObject.SetActive(false);
    }

    void SetLight(bool newState)
    {
        isActive = newState;
        gameObject.SetActive(newState);
    }

    private void Update()
    {
        if (isActive)
        {
            transform.rotation = Quaternion.Euler(transform.rotation.eulerAngles + new Vector3(0, turningRate * Time.deltaTime, 0));
            alarm.mute = false;
        }
        else
        {
            alarm.mute = true;
        }        
    }

    private void OnDestroy()
    {
        SetLights -= SetLight;
    }
}
