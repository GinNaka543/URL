using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ForkliftMovement : MonoBehaviour
{
    const float speed = 2;
    const float rotationSpeed = 50;
    ForkliftWaypoints waypoints;

    private void Awake()
    {
        waypoints = transform.parent.GetComponentInChildren<ForkliftWaypoints>();
    }

    int currentWaypoint = 0;
    Vector3 curWaypoint;

    float accelerationMultiplier;

    void Update()
    {
        if (Vector3.Distance(VectorFuncs.RemoveY(curWaypoint, transform.position.y), transform.position) < 1)
        {
            currentWaypoint++;
            if (waypoints.waypoints.Count - 1 < currentWaypoint)
            {
                currentWaypoint = 0;
            }
        }

        Quaternion lookRotation = Quaternion.LookRotation(VectorFuncs.RemoveY(Vector3.Normalize(curWaypoint - transform.position)));

        curWaypoint = waypoints.waypoints[currentWaypoint];
        transform.rotation = Quaternion.RotateTowards(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);

        if (Vector3.Distance(lookRotation.eulerAngles, transform.rotation.eulerAngles) < 10) {
            accelerationMultiplier = Mathf.Min(accelerationMultiplier + Time.deltaTime, 1);
        }
        else
        {
            accelerationMultiplier = Mathf.Max(accelerationMultiplier - Time.deltaTime * 3, 0);
        }
        transform.position += speed * Time.deltaTime *  VectorFuncs.RemoveY(Vector3.Normalize(curWaypoint - transform.position));
    }
}
