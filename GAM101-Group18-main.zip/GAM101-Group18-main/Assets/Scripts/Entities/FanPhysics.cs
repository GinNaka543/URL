using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FanPhysics : MonoBehaviour
{
    const float activationDelay = 6f;
    bool isOn;
    public float activationTimer = activationDelay;

    const float fanStrength = 125;

    private ParticleSystem windParticles;


    [SerializeField] private AudioSource windSound;

    private void Start()
    {
        windParticles = transform.GetChild(0).gameObject.GetComponent<ParticleSystem>();
        windParticles.Stop();
    }

    void FixedUpdate()
    {
        if (activationTimer > 0)
        {
            activationTimer -= Time.deltaTime;
            windParticles.Stop();
        }
        else
        {
            isOn = !isOn;
            activationTimer = activationDelay;

        }

        if (isOn)
        {
            windParticles.Play();

            if(!windSound.isPlaying)
                windSound.Play();

            float fanMultiplier = activationTimer < 1 ? activationTimer :
                activationTimer > 5 ? (activationDelay - activationTimer) : 1;
            foreach (Collider collider in Physics.OverlapBox(transform.position, transform.lossyScale / 2,new Quaternion(), ~(1 << LayerMask.NameToLayer("Bullet"))))
            {
                if (collider.GetComponent<Rigidbody>())
                {
                    float fanPower = (fanStrength * (1 - Vector3.Distance(transform.parent.position, collider.transform.position) / GetComponent<Collider>().bounds.size.z)) * fanMultiplier;

                    collider.GetComponent<Rigidbody>().AddForce
                        (Vector3.Normalize(VectorFuncs.RemoveY(collider.transform.position - transform.parent.position)) * fanPower);
                }
            }
        }
        else
        {
            windSound.Stop();
        }
    }
}
