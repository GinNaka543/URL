using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

abstract public class Part : Pickup
{
    public abstract SlotTypes PartType { get; }

    protected PartSlot slot;
    public PartSlot Slot { get { return slot; } }

    protected virtual void Start()
    {
        ForceItem();
    }

    private void ForceItem()
    {
        if (transform.parent)
        {
            PartSlot startSlot = transform.parent.GetComponent<PartSlot>();
            transform.parent = null;
            if (startSlot)
            {
                if (startSlot.contents != null)
                {
                    startSlot.contents.Disconnect();
                }

                gameObject.layer = LayerMask.NameToLayer("IgnoreMovement");
                rb.isKinematic = true;
                GetComponent<Collider>().isTrigger = true;
                SnapToSlot(startSlot);
                OnDrop();

            }
        }
    }

    protected override void WhileMoving()
    {
        Collider[] hitObjects = Physics.OverlapSphere((heldBy.PlayerCamera.transform.forward * heldDistance) + heldBy.PlayerCamera.transform.position, 0.5f, 1 << LayerMask.NameToLayer("EquipSlot"));
        foreach (Collider c in hitObjects)
        {
            if(SnapToSlot(c.GetComponent<PartSlot>())) return;
        }

        base.WhileMoving();

        if(slot != null)
        {
            slot.Marker.gameObject.SetActive(true);
        }
        slot = null;
    }

    private bool SnapToSlot(PartSlot partSlot)
    {

        if(partSlot.Owner == heldBy)
        {
            return false;
        }

        if (partSlot && partSlot.slotType == PartType && !partSlot.contents)
        {
            if (heldBy)
            {
                if(slot != partSlot && slot)
                {
                    slot.Marker.gameObject.SetActive(true);
                }
                partSlot.Marker.gameObject.SetActive(false);
            }

            slot = partSlot;
            transform.SetPositionAndRotation((partSlot.transform.position), (partSlot.transform.rotation));
            return true;
        }
        return false;
    }

    public override void Interact(PlayerController p)
    {
        if (slot)
        {
            AudioSource.PlayClipAtPoint(Resources.Load<AudioClip>("Sounds/Detach_sound"), transform.position);

            Disconnect();
        }
        ToggleSlotMarkers(p, true);
        base.Interact(p);
    }

    private void ToggleSlotMarkers(PlayerController p, bool show)
    {
        foreach (PartSlot otherPlayerSlot in PlayerManager.instance.GetOtherPlayer(p.PlayerID).GetComponent<PlayerController>().partSlots)
        {
            if (otherPlayerSlot.slotType == PartType)
            {
                if(show && otherPlayerSlot.contents)
                {
                    continue;
                }
                otherPlayerSlot.Marker.gameObject.SetActive(show);
            }
        }
    }

    protected void Disconnect()
    {
        OnRemove();
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        slot.contents = null;
        transform.parent = null;
    }

    protected override void OnDrop(PlayerController heldBy = null)
    {
        if (heldBy)
        {
            ToggleSlotMarkers(heldBy, false);
        }

        if (slot)
        {

            //Connect
            AudioSource.PlayClipAtPoint(Resources.Load<AudioClip>("Sounds/Attach_sound"), transform.position);

            rb.interpolation = RigidbodyInterpolation.None;
            transform.parent = slot.transform;
            slot.contents = this;
            slot.Owner.ItemEquipped();
            OnEquip?.Invoke();
            return;
        }

        base.OnDrop();
    }

    public delegate void Equip();
    public event Equip OnEquip;
    public event Equip OnRemove;
}
