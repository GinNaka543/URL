using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;
using UnityEngine;
using static Interactable;

public class BoxItems : MonoBehaviour
{
    [SerializeField] AudioSource boxSound;

    void Awake()
    {
        GetComponent<ObjectHealth>().OnDeath += Open;
    }

    protected void Open()
    {
        boxSound.Play();

        Destroy(gameObject);   
    }
}
