using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.UI;
using static UnityEngine.ProBuilder.AutoUnwrapSettings;

public class Overheat : MonoBehaviour
{
    float maxCooldown;
    float speed;
    ArmPart owner;

    float cooldown;

    bool overheated;
    public bool Overheated 
    { 
        get { return overheated; } 
        set
        {
            overheated = value;
            OnOverheated?.Invoke(value);
        }
    }

    public delegate void onOverheated(bool overheated);
    public event onOverheated OnOverheated;

    public delegate void onOverheatChanged(float amount, float maxValue);
    public event onOverheatChanged OnOverheatChanged;

    float Cooldown
    {
        get { return cooldown; }
        set
        {
            cooldown = Mathf.Clamp(value, 0, maxCooldown);
            if (overheated && value <= 0)
            {
                Overheated = false;
                isDecreasing = false;
            }
            else
            {
                if (value > maxCooldown)
                {
                    Overheated = true;
                }

                if (!isDecreasing)
                {
                    StartCoroutine(DecreaseCooldown());
                }
            }

            OnOverheatChanged?.Invoke(Cooldown, maxCooldown);
        }
    }

    /// <summary>
    /// Gives the weapon the ability to overheat if used too much
    /// </summary>
    /// <param name="maxCooldown">The point at which the weapon overheats</param>
    /// <param name="speed">How quickly the weapon coolsdown</param>
    /// <param name="owner">The weapon this is connected to</param>
    public static Overheat CreateOverheat(ArmPart owner, float maxCooldown, float speed)
    {
        Overheat newOverheat = owner.gameObject.AddComponent<Overheat>();
        newOverheat.Initialise(owner, maxCooldown, speed);
        return newOverheat;
    }

    void Initialise(ArmPart owner, float maxCooldown, float speed)
    {
        this.maxCooldown = maxCooldown;
        this.speed = speed;

        this.owner = owner;
        owner.OnEquip += AssignHUD;
        owner.OnRemove += RemoveHUD;
    }

    private OverheatBar GetAssignedBar()
    {
        return owner.Slot.Owner.GetComponent<HUDManager>().overheatBars.Where(bar => bar.IsLeftArm == (owner.Slot as ArmSlot).isLeft).ElementAt(0);
    }

    private void AssignHUD()
    {
        OverheatBar assignedBar = GetAssignedBar();
        OnOverheatChanged += assignedBar.UpdateBar;
        OnOverheated += assignedBar.OnOverheatChanged;
        OnOverheatChanged(Cooldown,maxCooldown);
        OnOverheated(overheated);
    }

    private void RemoveHUD()
    {
        OverheatBar assignedBar = GetAssignedBar();
        OnOverheatChanged -= assignedBar.UpdateBar;
        OnOverheated -= assignedBar.OnOverheatChanged;
        assignedBar.GetComponent<Image>().fillAmount = 0;
    }

    bool isDecreasing;
    IEnumerator DecreaseCooldown()
    {
        isDecreasing = true;
        while (isDecreasing)
        {
            Cooldown -= Time.deltaTime * speed * ((Convert.ToInt32(overheated) * 1.5f) + 1);
            yield return null;
        }
    }

    public void IncreaseCooldown(float amount)
    {
        Cooldown += amount;
    }
}
