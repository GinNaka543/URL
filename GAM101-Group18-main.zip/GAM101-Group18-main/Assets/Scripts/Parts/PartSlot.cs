using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Timeline;

public enum SlotTypes
{
    Arm, Wind
}

public class PartSlot : MonoBehaviour
{
    [SerializeField] int slotID;
    public int SlotID { get { return slotID; } }

    PlayerController owner;
    public PlayerController Owner { private set { owner = value; } get { return owner; } }

    public SlotTypes slotType;
    public Part contents;

    public Billboard Marker { get {  return marker; } }
    private Billboard marker;

    private void Awake()
    {
        SphereCollider equipTrigger = gameObject.AddComponent<SphereCollider>();
        equipTrigger.isTrigger = true;
        equipTrigger.radius = 0.4f;

        owner = GetComponentInParent<PlayerController>();
        owner.partSlots.Add(this);
    }

    private void Start()
    {
        var billboard = Billboard.CreateBillboard(Resources.Load("Sprites/Mark") as Texture2D,
            transform.position,
            "Player" + (owner.PlayerID == 0 ? 2 : 1), 0.15f);
        billboard.transform.parent = transform;
        marker = billboard;
        billboard.gameObject.SetActive(false);
    }
}