using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmSlot : PartSlot
{
    public bool isLeft;
}
