using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drops : MonoBehaviour
{
    private void Start()
    {
        GetComponent<ObjectHealth>().OnDeath += OnDeath;
    }

    [SerializeField] float dropChance = 0.05f;
    [SerializeField] float uncommonWeapon = 0.6f;
    [SerializeField] float rareWeapon = 0.5f;

    [SerializeField] Vector3 spawnOffset;

    // chances of the enemy dropping a weapon, common chance, uncommon chance, rare chance (5%, 2%, 0.5%)
    float[] dropChances;
    // when the enemy dies it generates a number that will define which weapon it should spawn or not spawn any at all

    private void Awake()
    {
        dropChances = new float[] { dropChance, uncommonWeapon, rareWeapon };
    }

    private void OnDeath()
    {
        int rarity = 0;
        foreach (float chance in dropChances)
        {
            if(Random.value <= chance)
            {
                rarity++;
                continue;
            }
            break;
        }

        // when the rarity variable does not equal to 0 it will randomly spawn a weapon from the resources, parts file 
        if (rarity != 0)
        {
            
            Object[] drops = Resources.LoadAll("Parts/" + rarity);
            // drops random weapon on the startPos where the enemy dies
            Instantiate(drops[Random.Range(0,drops.Length)] as GameObject).transform.position = transform.position + spawnOffset;
        }
    }
   // When enemy does drop a weapon it still has a chance to drop more than one weapon

}
