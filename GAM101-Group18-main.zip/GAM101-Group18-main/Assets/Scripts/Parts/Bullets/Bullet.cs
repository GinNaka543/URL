using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public static void CreateBullet(string type, Vector3 start, Vector3 dir, GameObject owner, int damage, float spread = 0, float speed = 20f)
    {
        Bullet bullet = (Instantiate(Resources.Load("Bullets/" + type)) as GameObject).GetComponent<Bullet>();
        bullet.transform.position = start;
        bullet.dir = Quaternion.Euler(Random.Range(-spread, spread), Random.Range(-spread, spread), 0) * dir;
        bullet.owner = owner;
        bullet.damage = damage;
        bullet.speed = speed;

        AudioSource.PlayClipAtPoint(Resources.Load<AudioClip>("Sounds/Gun_sounds"), start, owner.GetComponent<EnemyController>() ? 0.2f : 0.1f);
    }

    int damage;
    GameObject owner;
    public GameObject Owner { get { return owner; } }

    protected Vector3 dir;
    protected float speed;

    float destroyTimer = 6f;

    private void Update()
    {
        MoveBullet();

        if (destroyTimer < 0)
        {
            Destroy(gameObject);
        }
        else
        {
            destroyTimer -= Time.deltaTime;
        }
    }

    protected virtual void MoveBullet()
    {
        transform.position += speed * Time.deltaTime * dir;
    }

    private void OnTriggerEnter(Collider other)
    {
        ObjectHealth health = other.GetComponent<ObjectHealth>();

        if (owner == other.gameObject || other.gameObject.layer == LayerMask.NameToLayer("Ignore Raycast"))
        {
            return;
        }
        else if (health)
        {
            if (owner && owner.GetComponent<EnemyController>() && other.GetComponent<EnemyController>())
            {
                return;
            }

            if(owner && other)
                if(owner.GetComponent<PlayerController>() && other.GetComponent<PlayerController>())
                    if(PlayerPrefs.GetInt("FriendlyFire") != 1)
                    {
                        return;
                    }

            health.Damage(damage);
        }
        Destroy(gameObject);
    }
}