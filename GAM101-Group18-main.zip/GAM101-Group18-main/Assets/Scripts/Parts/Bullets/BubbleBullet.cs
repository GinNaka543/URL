using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BubbleBullet : Bullet
{
    private void Start()
    {
        float bulletSize = Random.Range(0.2f, 0.5f);
        transform.localScale = new Vector3(bulletSize, bulletSize, bulletSize);
        GetComponent<Rigidbody>().AddForce(dir * speed);
    }

    protected override void MoveBullet(){}
}
