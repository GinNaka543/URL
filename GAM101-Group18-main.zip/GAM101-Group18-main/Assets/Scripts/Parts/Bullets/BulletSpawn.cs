using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletSpawn : MonoBehaviour
{
    private void Awake()
    {
        GetComponentInParent<ArmPart>().spawnLocation = this;
    }
}
