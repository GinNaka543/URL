using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PistolArm : GunArm
{
    public override ItemDisplayInfo Info => new("Pistol", "A small manual gun that deals a bit of damage", "PistolUI");


    bool canShoot;
    protected override float Accuracy { get { return 0.5f; } }
    protected override float CooldownTime { get { return 0.5f; } }

    protected override void Use(bool isDown)
    {
        if (isDown)
        {
            if (!canShoot || cooldown > 0)
            {
                return;
            }

            canShoot = false;
            StartCoroutine(Cooldown());
            FireWeapon();

            return;
        }
        canShoot = true;
    }
}
