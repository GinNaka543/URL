using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Watergun : RifleArm
{
    public override ItemDisplayInfo Info => new("Water Gun", "Weak, fast firing weapon with no cooldown.", "watergun-icon");

    protected override float OverheatAmount { get { return 0.0f; } }
    protected override float CooldownTime { get { return 0.1f; } }
    protected override float Accuracy { get { return 3f; } }

    protected override void SpawnBullets()
    {
        Bullet.CreateBullet("Bubble", transform.position, AimDirection, slot.Owner.gameObject, 2, Accuracy, 200);
    }
}
