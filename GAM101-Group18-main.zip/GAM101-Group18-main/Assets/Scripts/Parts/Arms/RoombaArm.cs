using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RoombaArm : ArmPart
{
    public override ItemDisplayInfo Info => new("Roomba", "Press to fire a roomba, which'll seek out a target and explode. Up to 3 can be placed.", "RoombaUI");

    GameObject deployedRoomba;
    bool pressed;

    const int roombaLimit = 3;
    List<RoombaController> roombas = new List<RoombaController>();

    protected override void Awake()
    {
        OnEquip += Equipped;
        OnRemove += Unequipped;
        base.Awake();
    }

    protected override void Use(bool isDown)
    {
        if (isDown)
        {
            if (roombas.Count > roombaLimit)
            {
                roombas[0].GetComponent<ObjectHealth>().Damage(999);
            }
                
            if (!pressed)
            {
                pressed = true;
                deployedRoomba = Instantiate(Resources.Load("Entities/Roomba") as GameObject);
                deployedRoomba.transform.position = transform.position + (transform.forward * 1.5f);
                var roombaController = deployedRoomba.GetComponent<RoombaController>();
                roombaController.SetTarget();
                roombas.Add(roombaController); SetText();
                deployedRoomba.GetComponent<ObjectHealth>().OnDeath +=
                    delegate { roombas.Remove(roombaController); SetText(); };
            }
        }
        else
        {
            pressed = false;
        }
    }

    private void SetText()
    {
        HUDText.GetAssignedText(this).UpdateText(roombas.Count + " / " + roombaLimit);
    }

    private void Unequipped()
    {
        HUDText.GetAssignedText(this).gameObject.SetActive(false);
    }

    private void Equipped()
    {
        SetText();
        HUDText.GetAssignedText(this).gameObject.SetActive(true);
    }
}
