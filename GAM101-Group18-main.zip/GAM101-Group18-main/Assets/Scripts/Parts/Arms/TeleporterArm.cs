using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeleporterArm : PistolArm
{
    protected override float OverheatSpeed { get { return 0.05f; } }
    protected override float OverheatAmount { get { return 1.1f; } }

    public override ItemDisplayInfo Info => new("Teleporter", "A very bad arm that you really shouldn't use... It just teleports the other player to where you aim.");

    protected override void FireWeapon()
    {
        if (Overheat.Overheated)
        {
            return;
        }

        foreach (GameObject player in PlayerManager.instance.players)
        {
            if(player != slot.Owner.gameObject)
            {
                if (Physics.Raycast(transform.position, slot.Owner.PlayerCamera.transform.forward, out RaycastHit hit))
                {
                    if (Physics.OverlapCapsule(hit.point + new Vector3(0, .5f), hit.point + new Vector3(0, 1.5f), 0.48f).Length > 0)
                    {
                        return;
                    }
                    player.GetComponent<Rigidbody>().MovePosition(hit.point + new Vector3(0, 0.5f));
                    Overheat.IncreaseCooldown(OverheatAmount);
                }
            }
        }
    }
}
