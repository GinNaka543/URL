using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrapplingHookArm : ArmPart
{
    public override ItemDisplayInfo Info => new("Grapple Hook", "Hold to shoot the grapple at anything and it will drag you closer towards the grapple", "grapplinghook-icon");

    GameObject grappledObject;
    Vector3 grappledOffset;

    Transform wire;

    const float forceStrength = 100;
    MeshFilter mesh;

    [SerializeField] Mesh notGrappling;
    [SerializeField] Mesh grappling;

    bool pressed;
    protected override void Use(bool isDown)
    {
        if(isDown)
        {
            if (pressed)
            {
                return;
            }

            if (!grappledObject && Physics.Raycast(transform.position, slot.Owner.PlayerCamera.transform.forward, out RaycastHit hit, Mathf.Infinity, (1 << LayerMask.NameToLayer("Default")) | (1 << LayerMask.NameToLayer("Interactable")) | (1 << LayerMask.NameToLayer("Enemy")) | (1 << LayerMask.NameToLayer("Player2")) | (1 << LayerMask.NameToLayer("Player1"))))
            {                
                grappledObject = hit.transform.gameObject;
                grappledOffset = hit.point - grappledObject.transform.position;
                wire = (Instantiate(Resources.Load("Entities/Grapple")) as GameObject).transform;
                slot.Owner.MovementDisabled = true;
                pressed = true;
                mesh.mesh = grappling;
            }
        }
        else
        {
            if (!grappledObject)
            {
                return;
            }

            slot.Owner.MovementDisabled = false;
            grappledObject = null;
            Destroy(wire.gameObject);
            wire = null;
            pressed = false;
            mesh.mesh = notGrappling;
        }
    }

    protected override void Awake()
    {
        base.Awake();
        mesh = GetComponentInChildren<MeshFilter>();
    }

    private void FixedUpdate()
    {
        if (grappledObject)
        {
            Vector3 force = Time.deltaTime * forceStrength *
                Vector3.Distance(grappledObject.transform.position + grappledOffset, transform.position) *
                Vector3.Normalize(grappledObject.transform.position + grappledOffset - transform.position);

            slot.Owner.GetComponent<Rigidbody>().AddForce(force);
        }
    }

    private void Update()
    {
        if (!grappledObject)
        {
            return;
        }

        Vector3 grappleDir = Vector3.Distance(grappledObject.transform.position + grappledOffset, spawnLocation.transform.position) *
                     Vector3.Normalize(grappledObject.transform.position + grappledOffset - spawnLocation.transform.position);

        wire.position = grappleDir / 2 + spawnLocation.transform.position;
        wire.localScale = new Vector3(0.05f, Vector3.Distance(grappledObject.transform.position + grappledOffset, spawnLocation.transform.position) / 2, 0.05f);
        wire.rotation = Quaternion.Euler(Quaternion.LookRotation(Vector3.Normalize(grappleDir)).eulerAngles + new Vector3(90, 0, 0));
    }
}
