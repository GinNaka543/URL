using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HooverCollider : MonoBehaviour
{
    HooverArm hoover;
    List<GameObject> attractedBullets = new();

    private void Awake()
    {
        hoover = GetComponentInParent<HooverArm>();
    }

    IEnumerator AttractBullets()
    {
        while(true)
        {
            GameObject[] tempBullets = attractedBullets.ToArray();
            foreach(GameObject bullet in tempBullets)
            {
                if (!bullet)
                {
                    attractedBullets.Remove(bullet);
                    if (attractedBullets.Count <= 0)
                    {
                        yield break;
                    }
                    continue;
                }

                bullet.transform.position += Time.deltaTime * 10.0f * Vector3.Normalize(transform.position - bullet.transform.position);
                if(Vector3.Distance(bullet.transform.position, transform.position) < 0.1)
                {
                    Destroy(bullet);
                    hoover.StoredBullets++;
                }
            }
            yield return null;
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (hoover.StoredBullets + attractedBullets.Count + 1 <= hoover.MaxBullets && hoover.Pressed && other.GetComponent<Bullet>())
        {
            if(other.GetComponent<Bullet>().Owner == hoover.Slot.Owner.gameObject)
            {
                return;
            }

            Destroy(other.GetComponent<Bullet>());
            Destroy(other.GetComponent<Rigidbody>());
            
            if (attractedBullets.Count <= 0)
            {
                StartCoroutine(AttractBullets());
            }

            attractedBullets.Add(other.gameObject);
        }
    }
}
