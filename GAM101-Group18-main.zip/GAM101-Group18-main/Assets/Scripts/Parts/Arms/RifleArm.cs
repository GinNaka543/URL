using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RifleArm : GunArm
{
    public override ItemDisplayInfo Info => new("Rifle", "A big automatic gun, which deals lots of damage", "RifleUI");

    protected override float Accuracy { get { return 1f; } }
    protected override float OverheatSpeed { get { return 0.2f; } }
    protected override float OverheatAmount { get { return 0.075f; } }
    protected override float CooldownTime { get { return 0.3f; } }
    protected override int Damage => 15;

    protected override void Use(bool isDown)
    {
        if (isDown)
        {
            if (cooldown > 0)
            {
                return;
            }

            StartCoroutine(Cooldown());
            FireWeapon();
        }
    }
}
