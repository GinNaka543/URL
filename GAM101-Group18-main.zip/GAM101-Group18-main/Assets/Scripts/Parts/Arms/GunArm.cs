using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class GunArm : ArmPart
{
    protected float cooldown;
    protected virtual float Accuracy { get { return 0.0f; } }
    protected virtual float CooldownTime { get { return 0.0f; } }
    protected virtual int Damage => 20;

    public Vector3 AimDirection
    {
        get
        {
            if (Physics.Raycast(slot.Owner.PlayerCamera.transform.position, slot.Owner.PlayerCamera.transform.forward, out RaycastHit hit, Mathf.Infinity, ~(1 << LayerMask.NameToLayer("EquipSlot") | 1 << LayerMask.NameToLayer("IgnoreMovement") | 1 << LayerMask.NameToLayer("Ignore Raycast") | 1 << LayerMask.NameToLayer("GrabHitbox") | 1 << LayerMask.NameToLayer("Bullet") | 1 << LayerMask.NameToLayer("Player1") | 1 << LayerMask.NameToLayer("Player2"))))
            {
                return Vector3.Normalize(hit.point - transform.position);
            }

            return slot.Owner.PlayerCamera.transform.forward;
        }
    }

    protected override void Awake()
    {
        base.Awake();
        CreateOverheat();
    }

    protected virtual void SpawnBullets()
    {
        Bullet.CreateBullet("Bullet", SpawnOffset, AimDirection, slot.Owner.gameObject, Damage, Accuracy);
    }

    protected virtual void FireWeapon()
    {
        if (Overheat.Overheated)
        {
            return;
        }
        SpawnBullets();
        Overheat.IncreaseCooldown(OverheatAmount);
    }

    protected IEnumerator Cooldown()
    {
        cooldown = CooldownTime;
        while(cooldown > 0)
        {
            cooldown -= Time.deltaTime;
            yield return null;
        }
    }
}
