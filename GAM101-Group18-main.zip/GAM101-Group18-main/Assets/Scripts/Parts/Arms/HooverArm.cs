using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HooverArm : ArmPart
{
    public override ItemDisplayInfo Info => new("Hoover", "Hold whilst being shot at to hoover up all of the bullets then press to release all of the stored ammunition", "hoover-icon");

    bool pressed;
    public bool Pressed { get { return pressed; } }
    private int storedBullets;
    public int StoredBullets 
    { 
        get { return storedBullets; } 
        set 
        { 
            storedBullets = value;
            SetText();
        } 
    }
    public int MaxBullets { get { return 30; } }

    AudioSource hooverAudio;

    protected override void Awake()
    {
        OnEquip += Equipped;
        OnRemove += Unequipped;
        base.Awake();

        hooverAudio = gameObject.AddComponent<AudioSource>();
        hooverAudio.clip = Resources.Load<AudioClip>("Sounds/Hoover_sound_");
        hooverAudio.volume = 0.3f;
    }

    protected override void Use(bool isDown)
    {
        if (isDown)
        {
            pressed = true;
            if (!hooverAudio.isPlaying)
                hooverAudio.Play();
        }
        else if (pressed)
        {
            hooverAudio.Stop();

            pressed = false;
            for(int i = 0; i < StoredBullets; i++)
            {
                Bullet.CreateBullet("Bullet", transform.position, slot.Owner.PlayerCamera.transform.forward, slot.Owner.gameObject, 5, storedBullets / 8);
            }
            StoredBullets = 0;            
        }
    }

    private void SetText()
    {
        HUDText.GetAssignedText(this).UpdateText(storedBullets + " / " + MaxBullets);
    }

    private void Unequipped()
    {
        HUDText.GetAssignedText(this).gameObject.SetActive(false);
    }

    private void Equipped()
    {
        SetText();
        HUDText.GetAssignedText(this).gameObject.SetActive(true);
    }
}
