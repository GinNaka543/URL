using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShotgunArm : PistolArm
{
    public override ItemDisplayInfo Info => new("Shotgun", "A manual gun, which fires lots of bullets in a radius at once", "ShotgunUI");

    protected override float Accuracy { get { return 3f; } }
    protected override float OverheatSpeed { get { return 0.1f; } }
    protected override float OverheatAmount { get { return 0.25f; } }
    protected override int Damage => 15;

    const int bullets = 5;

    protected override void SpawnBullets()
    {
        for (int i = 0; i < bullets; i++)
        {
            base.SpawnBullets();
        }
    }
}
