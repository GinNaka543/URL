using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuadWielding : MonoBehaviour
{
    private void Awake()
    {
        for(int i = 0; i < transform.childCount; i++)
        {
            if(DifficultyManager.GetValue(DifParam.quadWield) == 1)
                transform.GetChild(i).gameObject.SetActive(true);
        }
    }
}
