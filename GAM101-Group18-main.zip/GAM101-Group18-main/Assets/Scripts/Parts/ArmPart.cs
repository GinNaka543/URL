using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ArmPart : Part
{
    public override SlotTypes PartType { get { return SlotTypes.Arm; } }

    protected virtual float OverheatSpeed { get { return 0.15f; } }
    protected virtual float OverheatAmount { get { return 0.1f; } }

    protected Overheat Overheat;

    [HideInInspector] public BulletSpawn spawnLocation;
    public Vector3 SpawnOffset { get { return spawnLocation ? spawnLocation.transform.position : transform.position; }}

    protected override void Start()
    {
        OnEquip += AssignName;
        OnRemove += UnassignName;

        OnEquip += AssignInputs;
        OnRemove += RemoveInputs;
        base.Start();
    }

    protected void CreateOverheat()
    {
        Overheat = Overheat.CreateOverheat(this, 1, OverheatSpeed);
    }

    void AssignName()
    {
        WeaponImage.GetAssignedText(this).UpdateImage(Info.image);
    }

    void UnassignName()
    {
        WeaponImage.GetAssignedText(this).UpdateImage("N/A");
    }

    void AssignInputs()
    {
        if (!slot.Owner)
        {
            return;
        }

        if((slot as ArmSlot).isLeft)
        {
            slot.Owner.leftArm += Use;
        }
        else
        {
            slot.Owner.rightArm += Use;
        }
    }

    void RemoveInputs()
    {
        if (!slot.Owner)
        {
            return;
        }

        if ((slot as ArmSlot).isLeft)
        {
            slot.Owner.leftArm -= Use;
        }
        else
        {
            slot.Owner.rightArm -= Use;
        }
    }

    protected abstract void Use(bool isDown);
}
