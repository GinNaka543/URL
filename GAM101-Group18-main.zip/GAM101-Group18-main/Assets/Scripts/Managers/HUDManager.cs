using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class HUDManager : MonoBehaviour
{
    public OverheatBar[] overheatBars;
    public HUDText[] hudText;
    public WeaponImage[] weaponNames;

    private void Awake()
    {
        overheatBars = GetComponentsInChildren<OverheatBar>();
        hudText = GetComponentsInChildren<HUDText>();
        weaponNames = GetComponentsInChildren<WeaponImage>();

        foreach(OverheatBar bar in overheatBars)
        {
            bar.GetComponent<Image>().fillAmount = 0;
        }

        foreach (WeaponImage weapon in weaponNames)
        {
            weapon.UpdateImage("N/A");
        }
        foreach (HUDText text in hudText)
        {
            text.gameObject.SetActive(false);
        }
        
    }
}
