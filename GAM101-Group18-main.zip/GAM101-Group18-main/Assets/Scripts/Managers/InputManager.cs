using UnityEngine.InputSystem;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    public static InputManager instance;
    public Gamepad[] usedGamepads = new Gamepad[2];

    public bool isPaused;

    public bool ControllersAreConnected => controllersAreConnected;
    bool controllersAreConnected;

    public delegate void ControllersVoid();
    public ControllersVoid ControllersConnected;
    public ControllersVoid ControllersDisconnected;

    void Awake()
    {
        instance = this;
        DontDestroyOnLoad(gameObject);

        ControllersConnected += delegate { controllersAreConnected = true; };
        Screen.SetResolution(1920, 1080, true);
    }

    private void Start()
    {
        Instantiate(Resources.Load<GameObject>("UI/ControllerScreen"));
        InputSystem.onDeviceChange += DeviceChange;
    }

    private void DeviceChange(InputDevice device, InputDeviceChange change)
    {
        if(change == InputDeviceChange.Disconnected)
        {
            int i = 0;
            foreach(var gamepad in usedGamepads)
            {
                if(gamepad == device)
                {
                    ControllersDisconnected();

                    usedGamepads[i] = null;
                    Instantiate(Resources.Load<GameObject>("UI/ControllerScreen"));
                }
                i++;
            }
        }
    }

    public void ResetDevices()
    {
        ControllersDisconnected?.Invoke();

        usedGamepads = new Gamepad[2];
        Instantiate(Resources.Load<GameObject>("UI/ControllerScreen"));
    }
}
