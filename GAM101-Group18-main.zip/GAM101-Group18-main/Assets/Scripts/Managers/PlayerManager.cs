using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Analytics;

public class PlayerManager : MonoBehaviour
{
    [HideInInspector] public static PlayerManager instance;
    [HideInInspector] public List<GameObject> players = new();

    private void Awake()
    {
        instance = this;
        Cursor.lockState = CursorLockMode.Locked;
    }

    public GameObject GetOtherPlayer(int id)
    {       
        return players.Where(player => player.GetComponent<PlayerController>().PlayerID == (id == 0 ? 1 : 0)).First();
    }

    public void AddPlayer(GameObject player)
    {
        players.Add(player);
        player.GetComponent<ObjectHealth>().OnDeath += OnPlayerDeath;
    }

    private void OnPlayerDeath()
    {
        bool bothDead = true;
        foreach (var player in players)
        {
            if (!player.GetComponent<ObjectHealth>().IsDead)
            {
                bothDead = false;
            }
        }

        if (bothDead)
        {
            GameOver();
        }
    }

    //VERY SAD DEATH STUFF GOES RIGHT HERE
    //    ||                        ||
    //    \/                        \/
    private void GameOver()
    {
        GameOverScreen.instance.ShowMenu();
    }
    //    /\                        /\
    //    ||                        ||
    //RIGHT THERE!!!!!!!!!!!!!!!!!!!!!!!!!!

    public void ForceItemToSlot(int playerID, GameObject partObject, int slotNumber)
    {
        foreach (GameObject player in players)
        {
            PlayerController controller = player.GetComponent<PlayerController>();
            if (controller.PlayerID == playerID)
            {
                foreach(PartSlot slot in controller.partSlots)
                {
                    if(slot.SlotID == slotNumber)
                    {
                        GameObject part = Instantiate(partObject);
                        part.transform.parent = slot.transform;
                        return;
                    }
                }
            }
        }
    }

    public NavMeshPath ClosestObject(Vector3 pos, GameObject[] targets, out GameObject closest)
    {
        NavMeshPath closestPath = new();
        closest = null;
        foreach (GameObject target in targets)
        {
            if (target.GetComponent<ObjectHealth>().IsDead)
            {
                continue;
            }

            NavMeshPath playerPath = new();

            if(!Physics.Raycast(target.transform.position + new Vector3(0,0.25f), Vector3.down, out RaycastHit hit, Mathf.Infinity, 1 << LayerMask.NameToLayer("Default")))
            {
                continue;
            }

            if (NavMesh.CalculatePath(pos, hit.point, NavMesh.AllAreas, playerPath) && playerPath.status == NavMeshPathStatus.PathComplete || playerPath.status == NavMeshPathStatus.PathPartial)
            {
                if (closest)
                {
                    if (VectorFuncs.PathLength(playerPath.corners) > VectorFuncs.PathLength(closestPath.corners))
                    {
                        continue;
                    }
                }
                closestPath = playerPath;
                closest = target;
            }
        }
        return closestPath;
    }
}
