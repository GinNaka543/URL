using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    private void Awake()
    {
        Instantiate(Resources.Load("UI/UI"));
    }
}
