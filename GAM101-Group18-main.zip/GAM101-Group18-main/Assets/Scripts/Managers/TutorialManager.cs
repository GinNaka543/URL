using System;
using System.Collections;
using UnityEngine;

public class TutorialManager : MonoBehaviour
{
    [Serializable]
    public struct TutorialData
    {
        [Header("Cool dialogue stuff")]
        public string title;
        public string[] dialogue;

        [Header("Ignore Meeeee!!!!!!!!!!")]
        public TutorialTask task;
    }

    [SerializeField]
    TutorialData[] taskData;

    public static TutorialManager instance;

    public delegate void TutorialVoidDelegate();
    public event TutorialVoidDelegate OnNewTask;

    int currentTaskIndex = 0;

    public TutorialData CurrentTask => taskData[currentTaskIndex];
    private TutorialTask task;

    private void Awake()
    {
        instance = this;
        OnDialogueFinished += delegate { dialogueFinished = true; };
    }

    private void Start()
    {
        InitialiseTask();
    }

    private void InitialiseTask()
    {
        task = Instantiate(CurrentTask.task);
        task.OnCreation();

        OnNewTask?.Invoke();
    }

    public void DialogueFinished()
    {
        OnDialogueFinished?.Invoke();
    }

    public void NextTask()
    {
        StartCoroutine(NextTask(.5f));
    }

    void EndTutorial()
    {
        NextLevel.OpenDoors();
        OnTutorialFinish();
    }

    public IEnumerator NextTask(float delay)
    {
        taskComplete = true;
        while(!dialogueFinished)
            yield return null;

        dialogueFinished = false;
        taskComplete = false;
        yield return new WaitForSeconds(delay);

        currentTaskIndex++;
        if (currentTaskIndex < taskData.Length)
            InitialiseTask();
        else
            EndTutorial();
    }

    bool dialogueFinished;
    [HideInInspector]
    public bool taskComplete;

    public delegate void UpdateCompletionTextDelegate(string text);
    public UpdateCompletionTextDelegate UpdateCompletionText;

    public TutorialVoidDelegate HideCompletionText;
    public event TutorialVoidDelegate OnDialogueFinished;

    public event TutorialVoidDelegate OnTutorialFinish;
}
