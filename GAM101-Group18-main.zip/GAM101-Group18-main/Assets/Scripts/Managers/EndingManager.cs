using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndingManager : MonoBehaviour
{
    public static EndingManager instance;

    int pressedButtons;

    AudioSource ambience;
    AudioSource victoryMusic;
    [SerializeField] private AudioClip victorySound;

    public int PressedButtons
    {
        get => pressedButtons;
        set
        {
            pressedButtons = value;
            if (pressedButtons >= 2)
            {
                ENDINGYIPPEEEEE();
            }
        }
    }

    private void ENDINGYIPPEEEEE()
    {
        Instantiate(Resources.Load("UI/EndingMenu"));

        MusicManager.instance.StopMusic();
        Destroy(ambience);
        victoryMusic.Play();
    }

    private void Awake()
    {
        instance = this;
    }

    private void Start()
    {
        ambience = GetComponentInChildren<AudioSource>();

        victoryMusic = gameObject.AddComponent<AudioSource>();
        victoryMusic.volume = 0.5f;
        victoryMusic.clip = victorySound;
        victoryMusic.loop = true;
    }
}
