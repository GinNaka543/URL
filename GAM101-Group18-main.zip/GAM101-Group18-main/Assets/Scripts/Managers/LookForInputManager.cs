using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookForInputManager : MonoBehaviour
{
    private void Awake()
    {
        if (!InputManager.instance)
        {
            Instantiate(Resources.Load("Managers/InputManager"));
        }
    }
     
}
