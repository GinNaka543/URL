using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveManager : MonoBehaviour
{
    public static SaveManager instance;
    private void Awake()
    {
        instance = this;
    }

    public void Save()
    {
        foreach(GameObject player in PlayerManager.instance.players)
        {
            SaveParts(player.GetComponent<PlayerController>());
        }
    }

    public string GetName(GameObject part)
    {
        string trimmedName = part.name;
        int firstBracket = trimmedName.LastIndexOf("(");

        if(firstBracket != -1)
            trimmedName = trimmedName.Substring(0, firstBracket);

        trimmedName = trimmedName.Replace(" ","");
        return trimmedName;
    }

    private void SaveParts(PlayerController player)
    {
        bool first = true;
        string items = string.Empty;
        foreach(PartSlot slot in player.partSlots)
        {
            if (slot.contents && slot.SlotID != -1)
            {
                if (!first)
                {
                    items += ",";
                }
                else
                {
                    first = false;
                }

                items += slot.SlotID + "|" + GetName(slot.contents.gameObject);
            }
        }

        PlayerPrefs.SetString("Player" + player.PlayerID, items);
    }

    public void Load(PlayerController player)
    {
        string loadout = PlayerPrefs.GetString("Player" + player.PlayerID);

        if(loadout.Length <= 0)
        {
            return;
        }

        foreach(string item in loadout.Split(","))
        {
            string[] itemData = item.Split("|");
            PlayerManager.instance.ForceItemToSlot(player.PlayerID, FindPartPrefab(itemData[1]), int.Parse(itemData[0]));
        }
    }

    private GameObject FindPartPrefab(string partName)
    {
        for(int i = 1; i <= 3; i++)
        {
            foreach(Object part in Resources.LoadAll("Parts/" + i.ToString()))
            {
                if(part.name == partName)
                {
                    return part as GameObject;
                }
            }
        }

        return null;
    }
}
