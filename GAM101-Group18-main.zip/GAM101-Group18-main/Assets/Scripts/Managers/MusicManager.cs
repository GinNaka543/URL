using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Timeline;

public class MusicManager : MonoBehaviour
{
    [SerializeField] AudioClip Music;
    AudioSource audioSource;

    public float bckgrdMusicVol = 1;

    [SerializeField] float startDelay = 15f;

    public static MusicManager instance;

    private void Awake()
    {
        instance = this;

        audioSource = gameObject.AddComponent<AudioSource>();
        audioSource.clip = Music;

        audioSource.loop = true;

        audioSource.volume = bckgrdMusicVol;
        audioSource.priority = 0;
    }

    private void Start()
    {
        StartCoroutine(DelayedStart());
    }

    private IEnumerator DelayedStart()
    {
        yield return new WaitForSeconds(startDelay);
        audioSource.Play();
    }

    public void StopMusic()
    {
        audioSource.Stop();
    }
}
