using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomDifficultyManager : MonoBehaviour
{
    public Difficulty customDifficulty = new();

    static public CustomDifficultyManager Instance => instance;
    static CustomDifficultyManager instance;

    private void Awake()
    {
        instance = this;
    }
}
