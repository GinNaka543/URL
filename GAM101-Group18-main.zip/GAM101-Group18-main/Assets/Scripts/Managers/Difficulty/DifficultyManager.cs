using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum DifParam
{
    graceTime, waveTime, enemyLimit, minEnemySpawn, maxEnemySpawn, enemyHealthMult, playerHealthMult, generatorHealthMult, quadWield
}

public class Difficulty
{
    public Dictionary<DifParam, float> difficultyValues = new();

    public bool ranked = false;

    public Difficulty()
    {
        difficultyValues.Add(DifParam.graceTime, 20);
        difficultyValues.Add(DifParam.waveTime, 30);

        difficultyValues.Add(DifParam.enemyLimit, 15);
        difficultyValues.Add(DifParam.minEnemySpawn, 2);
        difficultyValues.Add(DifParam.maxEnemySpawn, 4);

        difficultyValues.Add(DifParam.enemyHealthMult, 1);
        difficultyValues.Add(DifParam.playerHealthMult, 1);
        difficultyValues.Add(DifParam.generatorHealthMult, 1);

        difficultyValues.Add(DifParam.quadWield, 0);
    }

    public void SetKey(DifParam key, float newValue)
    {
        difficultyValues[key] = newValue;
    }
}

public class DifficultyManager : MonoBehaviour
{
    public static DifficultyManager Instance
    {
        get 
        {
            if (!instance)
                instance = Instantiate(new GameObject()).AddComponent<DifficultyManager>();
            return instance;
        }
    }
    static DifficultyManager instance;

    static public Difficulty Difficulty
    {
        get
        {
            if(Instance.difficulty == null)
            {
                Instance.difficulty = new();
            }
            return Instance.difficulty;
        }

        set { Instance.difficulty = value; }
    }
    Difficulty difficulty = new();

    static public float GetValue(DifParam difficultySetting)
    {
        return Difficulty.difficultyValues.GetValueOrDefault(difficultySetting);
    }

    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }
}
