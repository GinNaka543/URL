using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager Instance => instance;
    static ScoreManager instance;

    private void Awake()
    {
        if(instance)
        {
            Destroy(instance.gameObject);
        }

        if (!DifficultyManager.Difficulty.ranked)
        {
            return;
        }
        
        DontDestroyOnLoad(gameObject);
        instance = this;
    }

    public float CurrentTime => currentTime;
    [SerializeField]
    float currentTime;

    bool running = true;

    private void Update()
    {
        if(running)
            currentTime += Time.deltaTime;
    }

    public float EndRun()
    {
        running = false;
        return currentTime;
    }
}
