using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.PlayerLoop;

public class AIManager : MonoBehaviour
{
    public static AIManager instance;

    public List<EnemyController> enemies = new();
    public List<GameObject> generators = new();

    public delegate void onGeneratorsChanged(int Amount);
    public event onGeneratorsChanged OnGeneratorsChanged;

    public delegate void GracePeriodChanged(float gracePeriod);
    public GracePeriodChanged showGraceTimer;

    public delegate void OnEnemySpawnChanged(bool enemySpawnStatus);
    public OnEnemySpawnChanged EnemySpawnChanged;


    public bool CanSpawnEnemies
    {
        get => spawnEnemies;
        set
        {
            EnemySpawnChanged?.Invoke(value);
            spawnEnemies = value;
        }
    }
    [SerializeField] bool spawnEnemies = true;

    private void Awake()
    {
        instance = this;
        StartCoroutine(UpdatePaths());
    }

    public float graceTimer;
    public bool alarms = true;

    private void Start()
    {
        graceTimer = DifficultyManager.GetValue(DifParam.graceTime);
    }

    private void Update()
    {
        if (!spawnEnemies)
            return;
        

        if(alarms)
            LightMovement.SetLights?.Invoke(true);

        graceTimer -= Time.deltaTime;
        showGraceTimer?.Invoke(graceTimer);
        if (graceTimer < 0)
        {
            SpawnEnemies();
            graceTimer = DifficultyManager.GetValue(DifParam.waveTime);

            if (alarms)
            {
                LightMovement.SetLights?.Invoke(false);
                alarms = false;
            }
        }
    }

    private void SpawnEnemies()
    {
        GameObject[] tempGenerators = generators.ToArray();
        foreach(GameObject generator in tempGenerators)
        {
            var generatorComp = generator.GetComponent<Generator>();
            if (generatorComp.canSpawnCooldown <= 1)
            {
                StartCoroutine(SpawnEnemiesAtGenerator(generatorComp));
                generatorComp.canSpawnCooldown = DifficultyManager.GetValue(DifParam.waveTime);
            }
        }
    }

    public IEnumerator SpawnEnemiesAtGenerator(Generator generator)
    {
        for (int i = 0; i < Random.Range(Mathf.Min(DifficultyManager.GetValue(DifParam.minEnemySpawn), DifficultyManager.GetValue(DifParam.maxEnemySpawn)), DifficultyManager.GetValue(DifParam.maxEnemySpawn)); i++)
        {
            if (enemies.Count >= DifficultyManager.GetValue(DifParam.enemyLimit))
                break;

            if (generator)
            {
                StartCoroutine(generator.SpawnEnemy());
            }
            yield return new WaitForSeconds(0.3f);
        }
    }

    IEnumerator UpdatePaths()
    {
        while (true)
        {
            EnemyController[] tempEnemies = enemies.ToArray();
            foreach (EnemyController enemy in tempEnemies)
            {
                if (enemy && enemy.UpdatePathByManager)
                {
                    StartCoroutine(enemy.UpdatePath());
                }
                yield return null;
            }
            yield return null;
        }
    }

    public void RemoveGenerator(Generator generator)
    {
        generators.Remove(generator.gameObject);
        OnGeneratorsChanged?.Invoke(generators.Count);

        if(generators.Count <= 0)
            NextLevel.OpenDoors?.Invoke();
    }

    public void AddGenerator(Generator generator)
    {
        generators.Add(generator.gameObject);
        OnGeneratorsChanged?.Invoke(generators.Count);
        generator.canSpawnCooldown = DifficultyManager.GetValue(DifParam.graceTime);
    }

    public GameObject ClosestEnemyInSight(Vector3 position)
    {
        GameObject closestEnemy = null;
        float closest = Mathf.Infinity;
        foreach(EnemyController enemy in enemies)
        {
            if(enemy is RoombaController)
            {
                continue;
            }

            float currentDistance = Vector3.Distance(enemy.transform.position, position);
            if (closest > currentDistance && Physics.Raycast(position,Vector3.Normalize(enemy.transform.position - position),out RaycastHit hit,Mathf.Infinity, ~(1 << LayerMask.NameToLayer("EquipSlot") | 1 << LayerMask.NameToLayer("Ignore Raycast") | 1 << LayerMask.NameToLayer("GrabHitbox") | 1 << LayerMask.NameToLayer("IgnoreMovement"))))
            {
                if(hit.transform.gameObject == enemy.gameObject)
                {
                    closest = currentDistance;
                    closestEnemy = enemy.gameObject;
                }
            }
        }

        return closestEnemy;
    }
}
