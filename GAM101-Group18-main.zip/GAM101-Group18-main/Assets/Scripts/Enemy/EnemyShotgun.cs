using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShotgun : EnemyWeapon
{
    const int bullets = 5;
    protected override void Shoot()
    {
        EnemyController controller = GetComponentInParent<EnemyController>();
        for (int i = 0; i < bullets; i++)
        {
            Bullet.CreateBullet("EnemyBullet", transform.position, Vector3.Normalize(controller.Target.transform.position - transform.position), controller.gameObject, Random.Range(1, 6), 3f);
        }
    }
}
