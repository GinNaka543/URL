using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyWeapon : MonoBehaviour
{
    [SerializeField] float cooldownStart = 0.5f;

    private bool useWeapon;
    public bool UseWeapon
    {
        get { return useWeapon; }
        set
        {
            useWeapon = value;
            if (useWeapon)
            {
                StartCoroutine(Shooting());
            }
        }
    }

    protected float ShootCooldownStart { get { return cooldownStart; } }
    float shootCooldown;

    IEnumerator Shooting()
    {
        while (useWeapon)
        {
            if (shootCooldown <= 0)
            {
                Shoot();
                shootCooldown = ShootCooldownStart;
            }
            else
            {
                shootCooldown -= Time.deltaTime;
            }
            yield return null;
        }

        shootCooldown = ShootCooldownStart;
    }

    protected virtual void Shoot()
    {
        EnemyController controller = GetComponentInParent<EnemyController>();
        Bullet.CreateBullet("EnemyBullet",transform.position, Vector3.Normalize(controller.Target.transform.position - transform.position), controller.gameObject, Random.Range(3,12), 0.5f);
    }
}
