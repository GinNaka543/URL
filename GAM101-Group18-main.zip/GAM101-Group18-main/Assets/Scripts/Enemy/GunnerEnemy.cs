using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class GunnerEnemy : EnemyController
{
    bool canSeeTarget;

    const float reactionTimeStart = 1f;
    float reactionTime = reactionTimeStart;

    EnemyWeapon weapon;

    protected override void Awake()
    {
        base.Awake();
        weapon = GetComponentInChildren<EnemyWeapon>();
    }

    protected override void MoveToTarget()
    {
        Vector3 dir = PointDir();
        FaceTarget(dir);
        Movement(dir * Convert.ToInt32(!canSeeTarget));
        
    }

    private void Update()
    {
        if (!isPacifist)
        {
            CanSeeTarget();
            Attack();
        }
        else
        {
            canSeeTarget = false;
            weapon.UseWeapon = false;
        }
    }

    const float checkStart = 0.1f;
    float nextCheck = 0f;

    private void CanSeeTarget()
    {
        nextCheck -= Time.deltaTime;
        if(nextCheck <= 0)
        {
            if (Target && Physics.Raycast(transform.position, Vector3.Normalize(Target.transform.position - transform.position), out RaycastHit hit, 20f, ~(1 << LayerMask.NameToLayer("Pickup") | 1 << LayerMask.NameToLayer("Bullet") | 1 << LayerMask.NameToLayer("Ignore Raycast") | ~CheckMask)) && hit.transform.gameObject == Target)
            {
                canSeeTarget = true;
                nextCheck = checkStart;
            }
            else
            {
                canSeeTarget = false;
                reactionTime = reactionTimeStart;
                weapon.UseWeapon = false;
            }
        }
    }

    private void Attack()
    {
        if (canSeeTarget)
        {
            if(reactionTime <= 0)
            {
                if (!weapon.UseWeapon)
                {
                    weapon.UseWeapon = true;
                }
            }
            else
            {
                reactionTime -= Time.deltaTime;
            }
        }
    }
}
